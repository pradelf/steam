# Databricks notebook source
# MAGIC %md
# MAGIC # Data exploration
# MAGIC
# MAGIC In this exercise we will explore a dataset that was created using the youtube API to gather information about videos on the platform, the response from the API is a json file (sort of dictionnary) containing the response to each call to the API.

# COMMAND ----------

filepath = "s3://full-stack-bigdata-datasets/Big_Data/YOUTUBE/songs.json"


# COMMAND ----------

df = spark.read.format('json').load(filepath)

# COMMAND ----------

# MAGIC %md
# MAGIC 1. Count the number of entries in `df`

# COMMAND ----------

df.count()

# COMMAND ----------

# MAGIC %md
# MAGIC 2. Display your DataFrame

# COMMAND ----------

display(df)

# COMMAND ----------

# MAGIC %md
# MAGIC Some people are very fond of DataBricks' `display(...)`  
# MAGIC However, it's limited to DataBricks, and it's a little slow...
# MAGIC
# MAGIC The alternative `.show(...)` has a very hard to read formatting...
# MAGIC
# MAGIC Actually, there is another way: limit the results to a decent amount of rows (one that can be collected without hogging all your memory) and then convert your PySpark DataFrame into a pandas DataFrame.
# MAGIC
# MAGIC Just **make sure you're not running `df.toPandas().head()`**, in theory the result would be the same but you would end up computing your whole DataFrame and storing into memory, if your data is big, that would be a **horrible idea**.
# MAGIC
# MAGIC 3. Get the first 5 rows of `df` as a pandas DataFrame and print them out (using notebook formatting)

# COMMAND ----------

df.limit(5).toPandas()

# COMMAND ----------

# MAGIC %md
# MAGIC 4. Print out the schema of `df`

# COMMAND ----------

df.printSchema()

# COMMAND ----------

# MAGIC %md
# MAGIC What can you say about the schema? Is it what you expected?
# MAGIC
# MAGIC How many columns would you say there are right now?
# MAGIC Looking at the schema, how many columns would you say there would be in this DataFrame after flattening it?

# COMMAND ----------

# MAGIC %md
# MAGIC 5. Print out the columns of `df`

# COMMAND ----------

df.columns

# COMMAND ----------

# MAGIC %md
# MAGIC That's 4 columns, although the schema seems much more complicated.
# MAGIC
# MAGIC This is because we have **nested structures**.
# MAGIC
# MAGIC Let's investigate each column one by one.

# COMMAND ----------

# MAGIC %md
# MAGIC ### Column `etag`
# MAGIC 6. Take the first 5 rows of the column `etag`

# COMMAND ----------

df.select('etag').take(5)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Column `kind`
# MAGIC How many different values do we have for the column `kind`?
# MAGIC
# MAGIC 7. Count the number of different values in the column `kind`

# COMMAND ----------

df.select('kind').distinct().count()

# COMMAND ----------

# MAGIC %md
# MAGIC Only one, **we can `.collect(...)` this**, this won't crash our memory..
# MAGIC
# MAGIC 8. Collect the distinct values in the column `kind`

# COMMAND ----------

df.select('kind').distinct().collect()

# COMMAND ----------

# MAGIC %md
# MAGIC Surprised by the result?
# MAGIC No the result is not too suprising since each row in the dataset represents a response from the youtube API.

# COMMAND ----------

# MAGIC %md
# MAGIC ### Column `pageInfo`
# MAGIC 9. Show the first 5 rows of the `pageInfo` column

# COMMAND ----------

df.select('pageInfo').show(5)

# COMMAND ----------

# MAGIC %md
# MAGIC What's this? Let's count how many different values...

# COMMAND ----------

# MAGIC %md
# MAGIC 10. Count the number of distinct values in the column `pageInfo`

# COMMAND ----------

df.select('pageInfo').distinct().count()

# COMMAND ----------

# MAGIC %md
# MAGIC Only a few, we can collect them all
# MAGIC
# MAGIC 11. Collect all distinct values from the column `pageInfo`

# COMMAND ----------

df.select('pageInfo').distinct().collect()

# COMMAND ----------

# MAGIC %md
# MAGIC This way we have more informations, that's the number of results we had for this specific API call..

# COMMAND ----------

# MAGIC %md
# MAGIC ### Column `items`
# MAGIC Last but not least, let's investigate the column `items`.
# MAGIC
# MAGIC What do you expect this column contains? Let's check if your intuition is right.
# MAGIC
# MAGIC 12. Show the first 5 rows of the column `items`

# COMMAND ----------

df.select('items').show(5)

# COMMAND ----------

# MAGIC %md
# MAGIC Not very useful... but `display` wouldn't help much either..  
# MAGIC You can give it a try in the next cell
# MAGIC
# MAGIC 13. Display the column `items` from df

# COMMAND ----------

display(df.select('items'))

# COMMAND ----------

# MAGIC %md
# MAGIC It's very difficult to see anything...
# MAGIC
# MAGIC Exploratory Data Analysis is a lot about knowing when to zoom in or zoom out.
# MAGIC
# MAGIC Right now, we're looking at the data from the surface and it's difficult to see anything. In the following steps, we will zoom in on a single element of the column `items` and try and see if we can understand its content better.

# COMMAND ----------

# MAGIC %md
# MAGIC We'll start by taking a single item and will call it `sample_item`
# MAGIC
# MAGIC 14. take 1 element of `items`: sample_item

# COMMAND ----------

sample_item = df.select('items').take(1)
sample_item

# COMMAND ----------

# MAGIC %md
# MAGIC What's the type of `sample_item`?
# MAGIC
# MAGIC 15. Print out the type of `sample_item`

# COMMAND ----------

type(sample_item)

# COMMAND ----------

# MAGIC %md
# MAGIC That's a `list`. How many elements does this list contains?
# MAGIC
# MAGIC 16. Print out the number of elements in `sample_item`

# COMMAND ----------

len(sample_item)

# COMMAND ----------

# MAGIC %md
# MAGIC Only one :)
# MAGIC
# MAGIC What do we do then?
# MAGIC
# MAGIC **We keep zooming in**: we will look inside the list.
# MAGIC
# MAGIC We will take the first (and only) element of the `sample_item`, remember `sample_item` is a `list`, and lists are [indexable](https://docs.python.org/2/reference/datamodel.html#emulating-container-types).
# MAGIC
# MAGIC 17. Take the first element of sample_item

# COMMAND ----------

row_item = sample_item[0]

# COMMAND ----------

# MAGIC %md
# MAGIC 18. Print out the type of `row_item`

# COMMAND ----------

type(row_item)

# COMMAND ----------

# MAGIC %md
# MAGIC No surprise we gave it the name `row_item`.  
# MAGIC Although, next time you do this by yourself, you might have to first zoom inside to understand what kind of variable we're dealing with so that you can then give it a proper name.
# MAGIC
# MAGIC As we keep zooming in, it's gonna get harder and harder to find good names for the variables.  
# MAGIC If we were doing production ready code, that would be a problem. But here, we're doing analysis, and our main objective is speed.  
# MAGIC That doesn't mean we should choose stupid names, that would make our code harder to read, but we don't have to obsess over it.
# MAGIC
# MAGIC This idea of finding good names for the variables you are using and any object you have to name in your code is important and is part of a programming philosophy of writing "legacy code". Legacy code is code that is here to stay and will be used and reused and updated many times and by many different people, therefore making it easy to read and understandable is essential. But if you think about it, any code is legacy code, when you'll come back to one of these exercises in the future or some old code you wrote to refresh your memory about something, you'll be glad you took some extra time to write clean and understandable code ;)
# MAGIC
# MAGIC 19. Print out the length of `row_item`

# COMMAND ----------

len(row_item)

# COMMAND ----------

# MAGIC %md
# MAGIC You know the drill, only one item in this sequence. Let's dig it out.
# MAGIC
# MAGIC 20. print out the first item of the `Row` object
# MAGIC
# MAGIC *NOTE: DO NOT USE `print(...)`, the notebook will just print it out itself it would not break, but it would be harder to use*

# COMMAND ----------

row_item[0]

# COMMAND ----------

# MAGIC %md
# MAGIC What do you think?
# MAGIC Looks like it contains a list!
# MAGIC
# MAGIC 21. print out the length of the first and only element of the `Row` object

# COMMAND ----------

len(row_item[0])

# COMMAND ----------

# MAGIC %md
# MAGIC 22. Import pyspark sql functions

# COMMAND ----------

from pyspark.sql import functions as F

# COMMAND ----------

# MAGIC %md
# MAGIC 23. Compute a new column that measures the size of the items column in the whole dataset: `items_size` then, show the first 10 lines of this new DataFrame
# MAGIC
# MAGIC *NOTE: we're just exploring you don't have to save the new DataFrame to a variable*

# COMMAND ----------

df.withColumn('items_size', F.size('items')).show(10)

# COMMAND ----------

# MAGIC %md
# MAGIC Can you see anything?

# COMMAND ----------

# MAGIC %md
# MAGIC It seems that each `item_size` is equal to each of the element of `pageInfo` 🤔.  
# MAGIC We will make sure of it, we will compare the `totalResults` field of `pageInfo` to the size of `items`, and if they're different we will filter them.
# MAGIC At the end we will count how many rows we got.
# MAGIC
# MAGIC To keep our eyes on the prize: we want to count how many rows have a subfield `totalResults` (inside the column `pageInfo`) that is different from the size of the field `items`.
# MAGIC
# MAGIC 24. filter on the column where the inside field `totalResults` of `pageInfo` is diffent from the size of `items` then count how many rows are left

# COMMAND ----------

#df.filter(F.col('pageInfo').getField('totalResults') != F.size('items')).count()
df.filter(F.col('pageInfo.totalResults') != F.size('items')).count()
#df.filter(df.pageInfo.totalResults != F.size('items')).count()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Conclusion
# MAGIC For each row of our dataframe, we actually have many different songs..  
# MAGIC When we called the API, we where calling batches of 50 songs. For each API call, we asked for 50 songs, and usually got a little bit less because some songs are not available on Youtube anymore.
# MAGIC
# MAGIC In our DataFrame each row is one API call.
# MAGIC
# MAGIC If we were more used to PySpark, we could actually have seen it earlier, and save ourselves some time.  
# MAGIC Indeed, print out the schema of `df`:
# MAGIC
# MAGIC 24. Print out the schema of `df`

# COMMAND ----------

df.printSchema()

# COMMAND ----------

# MAGIC %md
# MAGIC We've got our 4 top levels (corresponding to our 4 columns): `etag`, `items`, `kind`, `pageInfo`.
# MAGIC
# MAGIC `etag` and `kind` are of type `string`.
# MAGIC
# MAGIC `items` is different, its type is `array`, which means its a **container data type**, a type that contains multiple values.  
# MAGIC
# MAGIC We didn't get a table of songs, but instead a **table of API results**.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC Now that we understand what's going on, we need to find a way to get the data in the shape we want, e.g. one row per result and not one row per api call..  
# MAGIC That will be the topic of the next assignment.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## Take away
# MAGIC - Data we collect is not always in a tidy format. Sometimes it can actually be difficult to understand what we are manipulating.
# MAGIC - Zooming/dezooming strategy is very effective to quickly go through a dataset and reveal how it is structured.