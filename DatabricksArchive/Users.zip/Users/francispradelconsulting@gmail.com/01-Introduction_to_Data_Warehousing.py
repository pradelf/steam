# Databricks notebook source
# MAGIC %md
# MAGIC # Introduction to Data Warehousing
# MAGIC
# MAGIC The concept of Data Warehousing originated at IBM in the 80's. The goal of the initial research was to provide a framework to transfer data from operational systems to business intelligence departments, avoiding the cost and technical challenges of high redundancy.
# MAGIC
# MAGIC ## What will you learn in this course? 🧐🧐
# MAGIC
# MAGIC This lecture will introduce the concept of data warehousing and why do we need it. Here's the outline:
# MAGIC
# MAGIC * Why analysts cannot work directly on business databases?
# MAGIC * Data Warehouse VS Data Lake
# MAGIC * Data Warehouse VS traditional databases
# MAGIC     * Key differences
# MAGIC * Cloud vendors
# MAGIC * Amazon Redshift
# MAGIC     * Setup your own Redshift cluster
# MAGIC     * Tear down your Redshift cluster when you are done
# MAGIC * Using Redshift in PySpark
# MAGIC     * Writing to Redshift from PySpark DataFrame
# MAGIC     * Reading from Redshift onto a PySpark DataFrame
# MAGIC
# MAGIC ## Why analysts cannot work directly on business databases? 🤔🤔
# MAGIC
# MAGIC Business databases must stay clean at all cost: allowing Data Analysis or Data Scientist to access it introduces a breach.
# MAGIC
# MAGIC Moreover, most of the time, unstructured data (i.e., not stored in any kind of databases) is required to do performant analysis. 
# MAGIC
# MAGIC A Warehousing solution allows the company to aggregate and store its data needed for analysis, without altering the databases used for operations.
# MAGIC
# MAGIC ## Data Warehouse VS Data Lake 🗄️🆚🌊
# MAGIC
# MAGIC You often hear both when discussing Big Data, however they are very different.
# MAGIC
# MAGIC Data Lakes are a big pool of raw data, with no defined purposes: we store this unstructured data in prevision of future usage.
# MAGIC
# MAGIC Data Warehouse holds **processed** and **structured** data, ready to be used for advanced analytics. 
# MAGIC
# MAGIC Most of the time, data that ends up in the Warehouse was previously stored in the Lake. 
# MAGIC
# MAGIC - Step 1: Data is collected and stored in its raw form in a Data Lake,
# MAGIC - Step 2: Data is extracted from the Lake, cleaned and processed,
# MAGIC - Step 3: Data is loaded in the warehouse, ready to be queried.
# MAGIC
# MAGIC ## Data Warehouse VS traditional databases 🗄️🗄️🗄️🆚🗄️
# MAGIC
# MAGIC Roughly, a Data Warehouse **is** a relational database. It's just a little more than that.
# MAGIC
# MAGIC ### Key differences 🔑
# MAGIC
# MAGIC 1. The Warehouse can hold data from many databases.
# MAGIC 2. Any data stored in the Warehouse is stored for **analytics purposes only**.
# MAGIC 3. Data within a warehouse has been processed to simplify the analysis, and avoid the need for SQL queries that spread on 300 lines.
# MAGIC 4. Whereas databases are optimized for extracting rows (or observations), data warehouses are optimized to have a performance boost on columns (or fields).
# MAGIC
# MAGIC In a nutshell: warehouses are optimized for performant analysis.
# MAGIC
# MAGIC **A warehouse is the perfect candidate for `LOAD` destination in ETL pipelines.**
# MAGIC
# MAGIC ## Cloud vendors ☁️☁️
# MAGIC
# MAGIC - BigQuery, owned by Google, and part of the Google Cloud Platform,
# MAGIC - Redshift, owned by Amazon and part of the AWS platform,
# MAGIC - Snowflake,
# MAGIC - ...
# MAGIC
# MAGIC As always when choosing between different vendors, the cost structure is one the most important aspects to check. For instance, BigQuery storage is **much** cheaper than Redshift, but querying data on Redshift is **free** whereas it costs about 5 dollars/TB on BigQuery. Depending on your need, one solution might be more suitable than the other.

# COMMAND ----------

# MAGIC %md
# MAGIC ## Amazon Redshift 🔴🔴
# MAGIC
# MAGIC Redshift is the Data Warehousing solution from Amazon Web Services. As every services of the AWS family, Redshift is **Cloud-based**: you only pay for the compute and storage, and you don't have to take care of maintenance costs, or scaling the hardware to support an increasing load.
# MAGIC
# MAGIC Amazon Redshift Serverless automatically provisions data warehouse capacity and intelligently scales the underlying resources. Amazon Redshift Serverless adjusts capacity in seconds to deliver consistently high performance and simplified operations for even the most demanding and volatile workloads.
# MAGIC
# MAGIC **If you have never used Amazon Redshift Serverless before, you are eligible for a $300 credit, which can be used within 90 days of sign-up toward your compute and usage use !**
# MAGIC
# MAGIC ### Creating a Redshift Serverless cluster
# MAGIC
# MAGIC Go to your AWS Console and look for Redshift. Check you are on a good location, here `Paris`. Click on _Try Redshift Serverless free trial_!
# MAGIC
# MAGIC <img src="https://full-stack-assets.s3.eu-west-3.amazonaws.com/M05-D03-Redshift/new/redshift1.png"/>
# MAGIC
# MAGIC In the configuration page, click on "Manage IAM roles" > "Create IAM role".
# MAGIC
# MAGIC <img src="https://full-stack-assets.s3.eu-west-3.amazonaws.com/M05-D03-Redshift/new/redshift2.png"/>
# MAGIC
# MAGIC Select "Any S3 bucket"  and click on "Create IAM role as default":
# MAGIC
# MAGIC <img src="https://full-stack-assets.s3.eu-west-3.amazonaws.com/M05-D03-Redshift/new/redshift3.png"/>
# MAGIC
# MAGIC At the end of the page, validate and wait for the cluster initialisation to complete (it may take up to 10 minutes).

# COMMAND ----------

# MAGIC %md
# MAGIC Then, you can click on "default-workgroup", and you should read "Available" in the status:
# MAGIC
# MAGIC <img src="https://full-stack-assets.s3.eu-west-3.amazonaws.com/M05-D03-Redshift/new/redshift4.png"/>
# MAGIC
# MAGIC Scroll down until you see the "Network and security" settings, and click on the "Edit" button:
# MAGIC <img src="https://full-stack-assets.s3.eu-west-3.amazonaws.com/M05-D03-Redshift/new/redshift5.png"/>
# MAGIC
# MAGIC In the configuration page, check "Turn on Publicly accessible":
# MAGIC <img src="https://full-stack-assets.s3.eu-west-3.amazonaws.com/M05-D03-Redshift/new/redshift6.png"/>
# MAGIC
# MAGIC The changes may take a few minutes.
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC Congratulations, your first redshift serverless cluster is ready !
# MAGIC
# MAGIC Now, let's create a connection between our notebook (on Databricks) and the redshift datawarehouse in order to read/write some data.
# MAGIC
# MAGIC To do so, you'll need some connection informations:
# MAGIC
# MAGIC * The JDBC URL is in the "default-workgroup" page:
# MAGIC
# MAGIC <img src="https://full-stack-assets.s3.eu-west-3.amazonaws.com/M05-D03-Redshift/new/redshift8.png"/>
# MAGIC
# MAGIC * The username is in the "default-namespace" page:
# MAGIC
# MAGIC <img src="https://full-stack-assets.s3.eu-west-3.amazonaws.com/M05-D03-Redshift/new/redshift9.png"/>

# COMMAND ----------

# MAGIC %md
# MAGIC ## Using Redshift in PySpark
# MAGIC
# MAGIC ### Writing to Redshift from PySpark DataFrame ✨➡🔴
# MAGIC
# MAGIC Let's show you how to use Redshift with PySpark. First, we are creating a simple Dataframe:

# COMMAND ----------

import pandas as pd
import numpy as np

data_dict = {'a': [1,2,3], 'b': [2,3,4], 'c': [3,4,5], 'd':[np.NaN,0,1], 'e':["apple","banana","orange"]}

pandas_df = pd.DataFrame.from_dict(
    data_dict
)

df = spark.createDataFrame(pandas_df)

df.show()

# COMMAND ----------

# MAGIC %md
# MAGIC Then you need to fill some informations:
# MAGIC
# MAGIC > The `REDSHIFT_FULL_PATH` is the URL JDBC from the workgroup panel we mentioned above 👆. Remember? 🙂
# MAGIC You'll have to modify it, by replacing "redshift" by "postgresql" in the url.
# MAGIC
# MAGIC > The `REDSHIFT_USER` is the Admin user name from the namespace panel
# MAGIC
# MAGIC > The `REDSHIFT_PASSWORD` is the password you set when you created the cluster. 
# MAGIC If you forgot your password, you can edit it by clicking on the "Actions" button in the default-namespace panel.

# COMMAND ----------

REDSHIFT_USER = "admin"
REDSHIFT_PASSWORD = "Tclmtp_2025"

REDSHIFT_FULL_PATH = "jdbc:postgresql://default-workgroup.018882981251.eu-west-3.redshift-serverless.amazonaws.com:5439/dev" # don't forget to replace "redshift" by "postgresql"
                                # for example it'll look like:
                                # "jdbc:postgresql://redshift-cluster-1.csssws1edn9m.eu-west-3.redshift.amazonaws.com:5439/dev"
REDSHIFT_TABLE = 'titi'

# COMMAND ----------

# MAGIC %md
# MAGIC We can then write to our Redshift:

# COMMAND ----------

mode = "overwrite"

properties = {"user": REDSHIFT_USER, "password": REDSHIFT_PASSWORD, "driver": "org.postgresql.Driver"}

df.write.jdbc(url=REDSHIFT_FULL_PATH, table=REDSHIFT_TABLE, mode=mode, properties=properties)

# COMMAND ----------

# MAGIC %md
# MAGIC The 4 `mode` to choose from are:
# MAGIC
# MAGIC - `overwrite`: drop the table if it exists, then load the data in a new one,
# MAGIC - `append`: create the table if it does not exists, else append the data to the existing table,
# MAGIC - `error` (default): create the table or raise an error if it exists,
# MAGIC - `ignore`: same as `overwrite`, but does nothing if table already exists.

# COMMAND ----------

# MAGIC %md
# MAGIC Once you've executed the cells above, you can check that the data has been written into redshift, by clicking on the "query data" button in the namespace panel. A window like the one below should appear:
# MAGIC
# MAGIC <img src="https://full-stack-assets.s3.eu-west-3.amazonaws.com/M05-D03-Redshift/new/redshiftquery.png"/>
# MAGIC
# MAGIC On the left side, you should find a table in Serverless > dev > public > Tables.
# MAGIC You can also use the SQL query editor on the right to query the table.

# COMMAND ----------

# MAGIC %md
# MAGIC ### Reading from Redshift onto a PySpark DataFrame 🔴➡✨
# MAGIC
# MAGIC We can read from our Redshift in few lines:

# COMMAND ----------

properties = {"user": REDSHIFT_USER, "password": REDSHIFT_PASSWORD, "driver": "org.postgresql.Driver"}

table = sqlContext.read.jdbc(url=REDSHIFT_FULL_PATH, table=REDSHIFT_TABLE, properties=properties)

table.show()

# COMMAND ----------

# MAGIC %md
# MAGIC Although this can be useful, it is also possible to query your database using the Redshift query editor directly, which is most likely what data analysts and business analysts would be doing in a real-life context.
# MAGIC
# MAGIC Congrats! 👏 You just created your first data warehouse using Redshift! Do not forget to 👉 **[tear down your Redshift cluster](#how-to-tear-down-your-redshift)** 👈 or you run the risk of being charged.

# COMMAND ----------

# MAGIC %md
# MAGIC ### How to tear down your Redshift?
# MAGIC
# MAGIC When you have finished working with your Redshift cluster we advise your to ⚠️ **tear down your Redshift cluster so as to avoid too much costs.** ⚠️
# MAGIC
# MAGIC It is easy, just follow the following steps:
# MAGIC
# MAGIC Go to the default-workgroup panel, click on Actions > Delete workgroup
# MAGIC
# MAGIC <img src="https://full-stack-assets.s3.eu-west-3.amazonaws.com/M05-D03-Redshift/new/redshiftdelete1.png"/>
# MAGIC
# MAGIC In the confirmation page, enter the word "delete", then check "Delete the associated namespace default-namespace", uncheck "Create final snapshot" and write again "delete" in the end of the page:
# MAGIC
# MAGIC <img src="https://full-stack-assets.s3.eu-west-3.amazonaws.com/M05-D03-Redshift/new/redshiftdelete3.png"/>
# MAGIC
# MAGIC It may happen that the default-namespace can't be deleted at this point. In this case, some error message will pop-up. Then, just go into the default-namespace panel, click on "Actions" > "Delete namespace":
# MAGIC
# MAGIC <img src="https://full-stack-assets.s3.eu-west-3.amazonaws.com/M05-D03-Redshift/new/redshiftdelete4.png"/>
# MAGIC
# MAGIC Uncheck "create final snapshot" and write "delete" to confirm:
# MAGIC
# MAGIC <img src="https://full-stack-assets.s3.eu-west-3.amazonaws.com/M05-D03-Redshift/new/redshiftdelete5.png"/>
# MAGIC
# MAGIC You're done ! The deletion is complete if there is no workgroup and no namespace appearing in your redshift dashboard.
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Ressources 📚📚
# MAGIC
# MAGIC - [A nice article on Alooma's blog](https://www.alooma.com/blog/database-vs-data-warehouse)
# MAGIC - [Amazon Redshift](https://docs.databricks.com/data/data-sources/aws/amazon-redshift.html#setting-a-custom-column-type)