# Databricks notebook source
# MAGIC %md
# MAGIC # First steps with PySpark
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Learning objectives
# MAGIC
# MAGIC - Get familiar with PySpark RDDs
# MAGIC - Become imbued with the concept of lazyness
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC Let's start by loading the file from it's URI: `s3://full-stack-bigdata-datasets/Big_Data/tears_in_rain.txt`
# MAGIC

# COMMAND ----------

spark
sc = spark.sparkContext

text_rdd = sc.textFile("s3://full-stack-bigdata-datasets/Big_Data/tears_in_rain.txt")

# COMMAND ----------

# MAGIC %md
# MAGIC Print out the first line to make sure everything went well.
# MAGIC

# COMMAND ----------

text_rdd.take(1)

# COMMAND ----------

# MAGIC %md
# MAGIC Good you remember how to load a file from a URI, however, most of the time you will need to access files from distributed files systems, like amazon S3, here we will show you how you can access the file from an S3 bucket using specific credentials.
# MAGIC

# COMMAND ----------

# When you try to load a non public file you will get an error

text_rdd = sc.textFile(
    "s3://full-stack-bigdata-datasets/Big_Data/tears_in_rain_not_public.txt"
)
text_rdd.take(1)

# Note that you will only get the error after trying to perform an action, that's only then that you are trying to access the data.

# COMMAND ----------

# MAGIC %md
# MAGIC 1. Load the file from `filepath` into a PySpark RDD into a `text_file` variable.
# MAGIC

# COMMAND ----------

filepath="s3://full-stack-bigdata-datasets/Big_Data/purple_rain.txt"
text_rdd = sc.textFile(filepath)

# COMMAND ----------

# MAGIC %md
# MAGIC 2. Print out `text_file`.
# MAGIC

# COMMAND ----------

text_rdd.take(1)

# COMMAND ----------

# MAGIC %md
# MAGIC 3. That doesn't tell us much, what would you do to see the first 3 elements of this RDD? Print out the first 3 elements of the `text_file`.
# MAGIC

# COMMAND ----------

text_file=text_rdd.take(3)
print(type(text_file))

# COMMAND ----------

# MAGIC %md
# MAGIC 4. What's the type of `text_file`?
# MAGIC

# COMMAND ----------

print(type(text_rdd))

# COMMAND ----------

# MAGIC %md
# MAGIC It's a PySpark `RDD`. It means we can call **actions** on it and it will return a result.
# MAGIC
# MAGIC We want the results to be all elements of the `rdd`.
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC 5. collect all elements of `text_file`.
# MAGIC

# COMMAND ----------

text_rdd.collect()

# COMMAND ----------

# MAGIC %md
# MAGIC 6. How many lines are there in `text_file`? Count the number of lines in `text_file`.
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC

# COMMAND ----------

liste=text_rdd.collect()
print(len(liste))

# COMMAND ----------

# MAGIC %md
# MAGIC 7. What's the length of each sentence? Call `.map(...)` on your rdd and give it a function that computes the lenght of a string: `lineLengths`
# MAGIC
# MAGIC _NOTE: `lineLengths` is how you should name your result variable_
# MAGIC

# COMMAND ----------

text_rdd.count()
lineLengths = text_rdd.map(lambda s: len(s))
text_rdd.take(3)
lineLengths.collect()

# COMMAND ----------

# MAGIC %md
# MAGIC 8. Take the first 3 elements of lineLengths
# MAGIC

# COMMAND ----------

lineLengths.take(3)

# COMMAND ----------

# MAGIC %md
# MAGIC 9. Collect all elements of lineLenghts
# MAGIC

# COMMAND ----------

liste_longueur=lineLengths.collect()

# COMMAND ----------

# MAGIC %md
# MAGIC 10. What's the average length? Compute the average value of `lineLengths`: `avgLength`
# MAGIC

# COMMAND ----------

avgLength=lineLengths.mean()

# COMMAND ----------

# MAGIC %md
# MAGIC 11. What's the type of `avgLength`? Print it out.
# MAGIC

# COMMAND ----------

print(type(avgLength))

# COMMAND ----------

# MAGIC %md
# MAGIC 12. Print out `avgLength`
# MAGIC

# COMMAND ----------

print(avgLength)

# COMMAND ----------

# MAGIC %md
# MAGIC 13. Now we want to compute the total length of the document. Compute the sum of all `lineLengths`: `totalLength`
# MAGIC

# COMMAND ----------

totalLength=0
for el in liste_longueur:
  totalLength+=el
print(totalLength)

# COMMAND ----------

# MAGIC %md
# MAGIC 14. What's the type of `totalLength`
# MAGIC

# COMMAND ----------

print(type(totalLength))

# COMMAND ----------

# MAGIC %md
# MAGIC 15. Print out `totalLength`
# MAGIC

# COMMAND ----------

print(totalLength)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Bonus: another way to compute the sum would be to use a `reducer`
# MAGIC
# MAGIC This is a step exercise to get you prepare for the next (optional) assignment.
# MAGIC
# MAGIC Your goal is to compute the sum of lineLenghts, just like we did, but this time using `.reduce(...)`.  
# MAGIC Here is the link to the [documentation](https://spark.apache.org/docs/latest/rdd-programming-guide.html#actions).
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC 16. Try to compute the total sum, but this time using `.reduce(...)`
# MAGIC

# COMMAND ----------

lineLengths.reduce(lambda a,b: a+b)

# COMMAND ----------

