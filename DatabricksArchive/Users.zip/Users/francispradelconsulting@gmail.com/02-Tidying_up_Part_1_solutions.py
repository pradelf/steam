# Databricks notebook source
# MAGIC %md
# MAGIC # Tidying up our data - Part 1

# COMMAND ----------

# MAGIC %md
# MAGIC # Learning objectives
# MAGIC
# MAGIC - Manipulate deeply nested json data and transform them into structured data ready to be loaded into a Data Warehouse.

# COMMAND ----------

# MAGIC %md
# MAGIC ## Loading our data from S3

# COMMAND ----------

filepath = "s3://full-stack-bigdata-datasets/Big_Data/YOUTUBE/songs.json"

# COMMAND ----------

df = spark.read.format('json').load(filepath, multiline=True)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tidying up
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC We have multiple issues with our data.  **It does not look like "tidy data" at all.**  
# MAGIC First, we have rows within rows...
# MAGIC And second, most of the data resides in deeply nested structure within the column items...
# MAGIC
# MAGIC We will fix the former, then handle the latter in the next notebook.

# COMMAND ----------

# MAGIC %md
# MAGIC ### 1. Fixing the rows
# MAGIC Remember the `.explode` method? [documentation](https://spark.apache.org/docs/2.1.0/api/python/pyspark.sql.html#pyspark.sql.functions.explode).  
# MAGIC What `.explode(...)` does, it "Returns a new row for each element in the given array or map." We will use a lot of it here!
# MAGIC
# MAGIC If you remember properly, that's exactly the kind of structures we have in the schema of our DataFrame for the `items` column.
# MAGIC
# MAGIC 1. Print out the schema of `df`

# COMMAND ----------

df.printSchema()

# COMMAND ----------

# MAGIC %md
# MAGIC 2. Import the PySpark SQL functions following usual convention

# COMMAND ----------

from pyspark.sql import functions as F

# COMMAND ----------

# MAGIC %md
# MAGIC 3. Use `.explode(...)` on the `items` column and count the number of results

# COMMAND ----------

df.select(F.explode('items')).count()

# COMMAND ----------

# MAGIC %md
# MAGIC If you got 3907 rows, you've made it, congrats! :)  
# MAGIC We will use this as our new working DataFrame:
# MAGIC - just do the same thing, but this time save the exploded dataset into a variable named `items_df`
# MAGIC - don't forget to give a proper alias to your newly compute column: `items`
# MAGIC - at the end, as a sanity check, make sure we have the right amount of columns in our new DataFrame
# MAGIC
# MAGIC 4. Follow previous instructions

# COMMAND ----------

items_df = df.select(F.explode('items').alias('items'))
items_df.count()

# COMMAND ----------

# MAGIC %md
# MAGIC We're making progress, we now have one row per result (e.g. song)!
# MAGIC
# MAGIC But each song is a deeply nested structure... We will take care of this in the following notebook.
# MAGIC
# MAGIC 5. Show the first 5 rows of the exploded dataset

# COMMAND ----------

items_df.limit(5).toPandas()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Wrap-up
# MAGIC
# MAGIC You learned how to use `.explode(...)` to split arrays values into their own rows! 🎉