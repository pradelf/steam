# Databricks notebook source
# MAGIC %md
# MAGIC # Tidy data and nested schemas
# MAGIC
# MAGIC Data tidying is the concept of structuring datasets to facilitate analysis.
# MAGIC
# MAGIC The principles of tidy data have been described in 2013 by statistician [Hadley Wickman](http://hadley.nz/) and closely tied to the principles of relational databases and Codd's relational algebra. They provide a standard way to organize data values within a dataset and can be synthetized as:
# MAGIC
# MAGIC - Each variable forms a column.
# MAGIC - Each observation forms a row.
# MAGIC - Each type of observational unit forms a table.
# MAGIC
# MAGIC ## What will you learn in this course? 🧐🧐
# MAGIC This course will demonstrate how to tidy up a Dataframe's schema. Here's the ouline:
# MAGIC
# MAGIC * Array operations and nested schemas
# MAGIC     * `F.size(...)`
# MAGIC     * `F.explode(...)`
# MAGIC     * `.groupBy()` again ;)
# MAGIC     * `.collect_list(...)`
# MAGIC * Deep Nested schema
# MAGIC     * `.getField(...)`
# MAGIC * Even deeper
# MAGIC * Advanced groupBy
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Array operations and nested schemas ⚙️⚙️
# MAGIC
# MAGIC In this lecture we will introduce some spark sql which we'll need in order to clean our datasets before we run further analysis.

# COMMAND ----------

spark

sc = spark.sparkContext

# COMMAND ----------

from pyspark.sql import functions as F # This will load the class where spark sql functions are contained
from pyspark.sql import Row # this will let us manipulate rows with spark sql

# COMMAND ----------

# MAGIC %md
# MAGIC Let's say we have some data about users, here we create a RDD from a dict, but in real life, we would obtain it through a pipeline or a query from a database.

# COMMAND ----------

users_dct = [
    {'id': 1, 'name': 'George', 'orders': [50.61, 31.32, 20.9]},
    {'id': 2, 'name': 'Hugues', 'orders': [133.8, 59.0, 40.03, 27.91]}
]
users_rdd = sc.parallelize(users_dct)
users_df = spark.createDataFrame(users_rdd.map(lambda x: Row(**x))) # this is called unpacking, 
# try this command with Row(x) and Row(*x) to understand what it does
users_df.show()

# COMMAND ----------

# The .createDataFrame(...) method is able to infer the data schema by itself
users_df.printSchema()

# COMMAND ----------

# MAGIC %md
# MAGIC Although Spark is able to infer the data schema by itself, it can be useful to design it yourself, let's try and do this.

# COMMAND ----------

from pyspark.sql.types import * # Import types to convert columns using spark sql

# COMMAND ----------

users_dct = [
    {'id': 1, 'name': 'George', 'orders': [50, 31, 20]},
    {'id': 2, 'name': 'Hugues', 'orders': [133, 59, 40, 27]}
]
users_rdd = sc.parallelize(users_dct)

# we create a variable schema as a list of StructField inside a StructType object
schema = StructType([
    StructField('id', IntegerType(), True), # the first column is of type Integer
    StructField('name', StringType(), True), # the second column is a String
    StructField('orders', ArrayType(IntegerType()), True) # the third column contains Array of Integer
])

users_df = spark.createDataFrame(users_rdd.map(lambda x: Row(**x)), schema=schema) # we feed the schema
# to the function using the appropriate argument
users_df.printSchema()
users_df.show()

# COMMAND ----------

# MAGIC %md
# MAGIC ### `F.size(...)`
# MAGIC
# MAGIC This function is able to calculate the number of elements inside an array type column

# COMMAND ----------

users_df \
    .withColumn('orders_quantity', F.size('orders')) \
    .drop('orders')
users_df.show()

# COMMAND ----------

# MAGIC %md
# MAGIC We get the size of the array, which is pretty nice, but what if we want to compute other aggregates like sum or average? It appears it's not trivial, we will go through one method but there are other, you can read more about it [here](https://databricks.com/blog/2017/05/24/working-with-nested-data-using-higher-order-functions-in-sql-on-databricks.html).

# COMMAND ----------

# MAGIC %md
# MAGIC ### `F.explode(...)`
# MAGIC Before we try to compute aggregate, let's ask another question: what if we want one row per order?  
# MAGIC An order is an observational unit which, according to the tidy principles, deserves it's own table.
# MAGIC
# MAGIC The explode function will take a column of type array, and make copies of the entire line so that each element of the array be represented on a separate entry of the table.

# COMMAND ----------

orders_df = users_df.withColumn('order', F.explode('orders'))
orders_df.printSchema()
orders_df.show()

# COMMAND ----------

# MAGIC %md
# MAGIC ### `.groupBy(...)`
# MAGIC Now we can compute the average order by customer with a `.groupBy(...)`.

# COMMAND ----------

aggregate_df=orders_df.groupBy('id', 'name') \
    .mean('order')

aggregate_df.show()

# here it's ok to just writethe column names, but don't forget that it's usually
# better to use the column objects instead to avoid errors 

# COMMAND ----------

orders_df.show()

# COMMAND ----------

# MAGIC %md
# MAGIC ### `.collect_list(...)`
# MAGIC The opposite transformation is **`.collect_list(...)`**.

# COMMAND ----------

collect_orders=orders_df.groupBy('id', 'name') \
    .agg(F.collect_list('order').alias('orders'))

collect_orders.show()

# COMMAND ----------

collect_orders.show()
aggregate_df.show()
orders_df.show()

# COMMAND ----------

# MAGIC %md
# MAGIC We got our original DataFrame back.

# COMMAND ----------

# MAGIC %md
# MAGIC ## Deep nested schema 🔩🔩
# MAGIC This time our schema will be a bit more difficult, we have a list of users with their orders, but not only we have the order amount, we also some additional details.

# COMMAND ----------

from pyspark.sql.types import *

# COMMAND ----------

users = [
    {'id': 1, 'name': 'George', 'orders': [
        {'id': 1, 'value': 55.1},
        {'id': 2, 'value': 78.31},
        {'id': 4, 'value': 52.13}
    ]},
    {'id': 2, 'name': 'Hughes', 'orders': [
        {'id': 3, 'value': 31.19},
        {'id': 5, 'value': 131.1}
    ]}
]
users_rdd = sc.parallelize(users)

schema = StructType([
    StructField('id', IntegerType(), True),
    StructField('name', StringType(), True),
    StructField('orders', ArrayType(
        StructType([
            StructField('id', IntegerType(), True),
            StructField('value', FloatType(), True)
        ])
    ), True)
])

users_df = spark.createDataFrame(users_rdd, schema=schema)
users_df.printSchema()
users_df.show()

# You'll see that the schema this time is a little deeper than before!

# COMMAND ----------

# Let's explode the orders column start unnesting the schema
orders_df = users_df.withColumn('orders', F.explode('orders'))
orders_df.printSchema()
orders_df.show()

# COMMAND ----------

# MAGIC %md
# MAGIC ### `.getField(...)`
# MAGIC We can access nested fields using `.getField(fieldname)`

# COMMAND ----------

orders_df \
    .withColumn('order_id', F.col('orders').getField('id')) \
    .show()


# F.col("col_name") returns the column object just like df.col_name or df["col_name"]

# COMMAND ----------

# MAGIC %md
# MAGIC Or using **`.`** notation, just like you would do to access a column inside a DataFrame object.

# COMMAND ----------

orders_df \
    .withColumn('order_id_2', F.col('orders.id')) \
    .show()

# COMMAND ----------

# Let's extract both the nested columns to get a flat schema
orders_df_flattened = orders_df \
    .withColumn('order_id', F.col('orders.id')) \
    .withColumn('order_value', F.col('orders.value')) \
    .drop('orders')
orders_df_flattened.show()

# COMMAND ----------

# It is now possible to aggregate this table using groupBy and some aggregation function like .sum
orders_df_flattened \
    .groupBy('name') \
    .sum('order_value') \
    .orderBy('sum(order_value)') \
    .show()

# COMMAND ----------

# Aliasing inline and descending sort
orders_df_flattened \
    .groupBy('name') \
    .agg(F.sum('order_value').alias('total_value')) \
    .orderBy(F.desc('total_value')) \
    .show()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Even deeper 🗜️🗜️
# MAGIC Let's now simulate an even deeper nested schema, and we will walk you through the process of unnesting it!

# COMMAND ----------

users = [
    {'id': 1, 'name': 'George', 'orders': [
        {'id': 1, 'items': [
            {'id': 1, 'category': 'shirt', 'price': 80, 'quantity': 4},
            {'id': 2, 'category': 'jeans', 'price': 130, 'quantity': 2}
        ]},
        {'id': 4, 'items': [
            {'id': 1, 'category': 'shirt', 'price': 80, 'quantity': 1},
            {'id': 3, 'category': 'shoes', 'price': 240, 'quantity': 1}
        ]}
    ]},
    {'id': 2, 'name': 'Hughes', 'orders': [
        {'id': 2, 'items': [
            {'id': 4, 'category': 'shorts', 'price': 120, 'quantity': 3},
            {'id': 1, 'category': 'shirt', 'price': 180, 'quantity': 2},
            {'id': 3, 'category': 'shoes', 'prices': 240, 'quantity': 1}
        ]},
        {'id': 3, 'items': [
            {'id': 5, 'category': 'suit', 'price': 2000, 'quantity': 1}
        ]}
    ]}
]
users_rdd = sc.parallelize(users)

schema = StructType([
    StructField('id', IntegerType(), True),
    StructField('name', StringType(), True),
    StructField('orders', ArrayType(
        StructType([
            StructField('id', IntegerType(), True),
            StructField('items', ArrayType(
                StructType([
                    StructField('id', IntegerType(), True),
                    StructField('category', StringType(), True),
                    StructField('price', IntegerType(), True),
                    StructField('quantity', IntegerType(), True)
                ])
            ))
        ])
    ), True)
])

users_df = spark.createDataFrame(users_rdd, schema=schema)
users_df.printSchema()
users_df.show()

# This schema is much deeper than the other two!

# COMMAND ----------

# We start by exploding the orders column, which where the nest resides
orders_df = users_df.withColumn('orders', F.explode('orders'))
orders_df.show()

# COMMAND ----------

# MAGIC %md
# MAGIC Now brace yourselves as we will walk you step by step through the process of unnesting this data schema!

# COMMAND ----------

items_df = (
    orders_df.withColumn('order_id', F.col('orders.id'))
    .withColumn('items', F.col('orders.items'))
    .drop('orders')
    .withColumnRenamed('name', 'user_name')
    .withColumnRenamed('id', 'user_id')
    .withColumn('items', F.explode('items'))
    .withColumn('item_id', F.col('items.id'))
    .withColumn('item_category', F.col('items.category'))
    .withColumn('item_price', F.col('items.price'))
    .withColumn('item_quantity', F.col('items.quantity'))
    .withColumn('total_price', F.col('item_price') * F.col('item_quantity'))
    .drop('items')
)
items_df.show()

# COMMAND ----------

# MAGIC %md
# MAGIC This is much better.
# MAGIC Unnesting may be a tedious task but it is an essential part of the process towards facilitating analysis, running analysis and sql type queries on a nested schema is hard, so it is definitely worthspending some time preparing your data so that everyone else saves time when they query your tables.

# COMMAND ----------

# MAGIC %md
# MAGIC ## Advanced groupBy 🧮🧮

# COMMAND ----------

# Here we group the data by item category and calculate the sum
items_df \
    .groupBy('item_category') \
    .sum('item_quantity') \
    .orderBy(F.desc('sum(item_quantity)')) \
    .show()

# COMMAND ----------

# MAGIC %md
# MAGIC You might want to alias, in this case, you change `.sum()` for `.agg()`. This is a little beyond the scope of today's lecture, but we'll show it to you before spending more time understanding aggregates in the following days.

# COMMAND ----------

items_df \
    .groupBy('item_category') \
    .agg(F.sum('item_quantity').alias('total_quantity')) \
    .orderBy(F.desc('total_quantity')) \
    .show()

# COMMAND ----------

# MAGIC %md
# MAGIC If I want to alias..

# COMMAND ----------

items_df \
    .groupBy('item_category') \
    .agg((F.sum('total_price') / F.sum('item_quantity')).alias('avg_sale')) \
    .orderBy(F.desc('avg_sale')) \
    .show()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Resources 📚📚
# MAGIC
# MAGIC * We strongly advice you take the time to read [the original paper from Wickam](https://vita.had.co.nz/papers/tidy-data.pdf).
# MAGIC You might want to look at this ressource which will be used in the exercises in order to flatten a very nested data schema.
# MAGIC * [Automatically and Elegantly flatten DataFrame in Spark SQL](https://stackoverflow.com/questions/37471346/automatically-and-elegantly-flatten-dataframe-in-spark-sql) on StackOverflow