# Databricks notebook source
from pyspark.sql import functions as F
filepath = "s3://full-stack-bigdata-datasets/Big_Data/youtube_playlog.csv"
playlog = (spark.read.format('csv')\
             .option('header', 'true')\
             .option('inferSchema', 'true')\
             .load(filepath))
playlog.show(5)

# COMMAND ----------

playlog.printSchema()

# COMMAND ----------

display(playlog.limit(5).describe())

# COMMAND ----------

# Given a column, we find the amount of missing values in it
playlog.filter(F.col('timestamp').isNull()).count()

# COMMAND ----------

for col in playlog.columns:
    missing_val_count = playlog.filter(F.col(col).isNull()).count()
    print(missing_val_count)

# COMMAND ----------

missing_dict = {col: playlog.filter(F.col(col).isNull()).count()
 for col in playlog.columns}

# COMMAND ----------

[missing_dict]

# COMMAND ----------

import pandas as pd
pd.DataFrame(missing_dict, index=['missing_vals'])

# COMMAND ----------

pd.DataFrame([missing_dict]) # pandas expects non-scalar values -> we pass a list of our dictionary to bypass this

# COMMAND ----------

{'c1': missing val count,
 'c2': missing val count}

# COMMAND ----------

import pandas as pd
pd.DataFrame({'Alice': [0], 'Bob': [1]})

# COMMAND ----------

playlog.dropDuplicates().count() == playlog.count()

# COMMAND ----------

playlog.count() - playlog.dropDuplicates().count()

# COMMAND ----------

playlog.orderBy(F.col('timestamp')).show(5)

# COMMAND ----------

playlog.filter(F.col('timestamp') < 0).count()

# COMMAND ----------

playlog.filter(F.col('timestamp') < 0).collect()

# COMMAND ----------

playlog_processed = playlog.dropDuplicates() \
    .filter(F.col('timestamp') > 0)

# COMMAND ----------

playlog_processed.count()

# COMMAND ----------

playlog.write.parquet('s3://full-stack-bigdata-datasets/Big_Data/playlog_processed_student.parquet')

# COMMAND ----------

