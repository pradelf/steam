# Databricks notebook source
# MAGIC %md
# MAGIC # Tidying up our data - Part 2
# MAGIC ## Flattening a nested schema

# COMMAND ----------

# MAGIC %md
# MAGIC As usual, we'll start by loading the data.  
# MAGIC Because we expect you to know how to setup things so that you can load data from S3, we're doing it for you now.  
# MAGIC Make sure you go through our code and check that you were actually using our best practices.

# COMMAND ----------

items_exploded_path = "s3://full-stack-bigdata-datasets/Big_Data/YOUTUBE/items_exploded.json"

df = spark.read.json(items_exploded_path)

# COMMAND ----------

# MAGIC %md
# MAGIC 1. As a sanity check, count the rows in the DataFrame

# COMMAND ----------

df.count()

# COMMAND ----------

# MAGIC %md
# MAGIC 2. Print out the schema of the DataFrame

# COMMAND ----------

df.printSchema()
df.show(5)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Working with the schema

# COMMAND ----------

# MAGIC %md
# MAGIC We're ready to get started :)
# MAGIC
# MAGIC Our schema is like a tree, we want to collect all its leaves and put them neatly as columns of our DataFrame.  
# MAGIC That's called **flattening a schema**.

# COMMAND ----------

# MAGIC %md
# MAGIC Let's give it a try with the `title` element inside the `items` columns, then into the nested field `snippet`, and finally in the nested subfield `title`.
# MAGIC
# MAGIC You can do this using the `.getField()` column method [documentation](https://spark.apache.org/docs/latest/api/python/reference/pyspark.sql/api/pyspark.sql.Column.getField.html).
# MAGIC
# MAGIC 3. Select the `title` subfield from the `snippet` subfield in the `items` column show the first 5 elements

# COMMAND ----------

from pyspark.sql import functions as F # This will load the class where spark sql functions are contained
from pyspark.sql import Row # this will let us manipulate rows with spark sql
#items > snippet > title
df.select(F.col('items.snippet.title')).show(5)
# la ligne suivante est équivalente à la ligne du dessus.
#df.select(F.col('items')).getField('snippet').getField('title').show()
df.withColumn('title', F.col('items.snippet.title'))
df.show(5)
df.describe()

# COMMAND ----------

df = df.withColumn('duration', F.col('items.contentDetails.duration')) \
       .withColumn('description', F.col('items.snippet.description')) \
       .withColumn('default_thumbnail_url', F.col('items.snippet.thumbnails.default.url'))

# COMMAND ----------

df.show(5)
df.schema.jsonValue()

# COMMAND ----------

# MAGIC %md
# MAGIC That's it, easy peasy 🙂.
# MAGIC
# MAGIC We could just keep doing this for every single leaf of the schema and we're done.
# MAGIC
# MAGIC I don't know about you, but I think this is incredebly **boring**. Also, what if tomorrow, Youtube adds a new leaf to its API results?
# MAGIC
# MAGIC Come on, we're programmers, we're **supposed to automate stuff, aren't we?**
# MAGIC
# MAGIC What we need is a way to build that list of leaves... 
# MAGIC Not gonna lie, it's not trivial, it's called a tree traversal and this is beyond the scope of this course.
# MAGIC
# MAGIC Which means we will do this part for you. In the following cell, we've included a function called `walkSchema`. What this functions does, is that it walk the schema of our DataFrame with a nested schema and harvest its leave. Returning them with full path like this `items.snippet.title` as a string.
# MAGIC
# MAGIC Well, "returning", not exactly. But we will see about that later.
# MAGIC
# MAGIC **[TODO]**
# MAGIC Take a look at the function, you're not supposed to understand what it does, this is beyond the scope of this course.  
# MAGIC But when you're learning, it's always a good idea to be exposed to new things.

# COMMAND ----------

# Let's give you the intuition for the flattening function we will share with you now
# The idea is to automatically dig deeper and deeper into the schema in order to extract
# all the column names in the form "array1.array2.array3.field1", let's go!

# we'll work with the schema in json format, which will be way easier to manipulate
df.schema.jsonValue()

# It's nothing more than a dictionnary with keys

# COMMAND ----------

df.schema.jsonValue().keys()
# Only two keys at this stage, type and fields, let's explore the type key

# COMMAND ----------

df.schema.jsonValue()["type"]
# The value associated is struct

# COMMAND ----------

# let's explore the content of the other key
df.schema.jsonValue()["fields"]

# COMMAND ----------

#it's a list, what's the first element?
df.schema.jsonValue()["fields"][0]

# COMMAND ----------

# what keys does it have ?
df.schema.jsonValue()["fields"][0].keys()

# COMMAND ----------

# the key name contains the name of the field
df.schema.jsonValue()["fields"][0]["name"]

# COMMAND ----------

# if we have the key type then we have subfields inside it
df.schema.jsonValue()["fields"][0]["type"]
# and we are back to the same structure we had at the beginning and we can start digging again
# that's the spirit of the function below

# COMMAND ----------

from pyspark.sql.types import StructType, StructField
from typing import List, Dict, Generator, Union, Callable

# This is actually written like a scala function, we'll walk you through it
def walkSchema(schema: Union[StructType, StructField]) -> Generator[str, None, None]:
    """Explores a PySpark schema:
    
    schema: StructType | StructField
    
    Yield
    -----
    A generator of strings, the name of each field in the schema
    """
    
    # we define a function _walk that produces a string generator from
    # a dictionnary "schema_dct", and a string "prefix"
    def _walk(schema_dct: Dict['str', Union['str', list, dict]],
              prefix: str = "") -> Generator[str, None, None]:
        assert isinstance(prefix, str), "prefix should be a string" # check if prefix is a string
        
        # this function returns "name" if there's no prefix and "prefix.name" if prefix exists
        fullName: Callable[str, str] = lambda name: ( 
            name if not prefix else f"{prefix}.{name}")
        
        # we get the next name one level lower from the dictionnary
        name = schema_dct.get('name', '')
        
        # if the type is struct then we search for the fields key
        # if fields is there we apply the function again and dig one level deeper in
        # the schema and set a prefix
        if schema_dct['type'] == 'struct':
            assert 'fields' in schema_dct, (
                "It's a StructType, we should have some fields")
            for field in schema_dct['fields']:
                yield from _walk(field, prefix=prefix)
        # if we have a dict type and we can't find fields then we
        # dig one level deeper and apply the _walk function again
        elif isinstance(schema_dct['type'], dict):
            assert 'fields' not in schema_dct, (
                "We're missing some keys here")
            yield from _walk(schema_dct['type'], prefix=fullName(name))
        # If we finally reached the end and found a name we yield the full name
        elif name:
            yield fullName(name)
    
    yield from _walk(schema.jsonValue())

# yield as opposed to return, returns a result but does not stop the function from running, it keeps
# running even after returning one result.

# COMMAND ----------

# MAGIC %md
# MAGIC We will give this function a try, and see how it behaves...  
# MAGIC You might have to look into PySpark documentation to learn how to access the schema of a DataFrame.
# MAGIC
# MAGIC 5. Call `walkSchema(...)` on our dataframe schema: `col_names` then print it out to the screen

# COMMAND ----------

exploded_df

# COMMAND ----------

# MAGIC %md
# MAGIC You should see an output similar to `<generator object walkSchema at 0x7f9eb0e390c0>`.  
# MAGIC It's a Python's generator, you can read more about it [here](https://jeffknupp.com/blog/2013/04/07/improve-your-python-yield-and-generators-explained/).
# MAGIC
# MAGIC For now, you just have to know, that just like a python's `list`, a `generator` is also `iterable`, which means we can iterate over it with a `for` loop.
# MAGIC
# MAGIC ```python
# MAGIC for e in my_generator:
# MAGIC     # You can access each element of the generator here
# MAGIC ```
# MAGIC
# MAGIC We'll give it a try, by printing out the values of our col_names.
# MAGIC
# MAGIC 6. Iterate over the walked schema
# MAGIC
# MAGIC *NOTE: give the name `col_name` to the iterating variable*

# COMMAND ----------



# COMMAND ----------

# MAGIC %md
# MAGIC Perfect, that's all the leafs of our schema.  
# MAGIC And we can just repeat the work we did with `items.snippet.title` for every column of this list.
# MAGIC
# MAGIC
# MAGIC There are a couple ways to do this, you've got at least 2 options (using standard "non-functionnal" python):
# MAGIC - build a list comprehension (or unpack the generator) and pass it to a `.select(...)` statement
# MAGIC - iterate over the generator, and use `.withColumn(...)`
# MAGIC
# MAGIC _But our favorite uses a functional approach. It particularly makes sense because Spark is based on Scala, a functionnal language.  
# MAGIC If you're interested in this approach, take a look at `reduce` from the `functools` package in Python.  
# MAGIC In this simple isolated case, it actually makes things look a bit harder than they should, but it would make it easier to neatly integrate this step in a global pipeline.  
# MAGIC **Beware, if you're not familiar with functional programming that will probably feel non-trivial.**_

# COMMAND ----------

from functools import reduce

from pyspark.sql import functions as F

# Non-functional way: unpacking the generator
# exploded_df = df.select(*walkSchema(df.schema))

# The functional way, using functools' reduce
exploded_df = reduce(
  lambda memo_df, col_name: memo_df.withColumn(col_name, F.col(col_name)),
  walkSchema(df.schema), df
).drop('items')

exploded_df.limit(5).toPandas()

# COMMAND ----------

# MAGIC %md
# MAGIC How amazing what we can do with a couple lines of well written code, isn't it?

# COMMAND ----------

# MAGIC %md
# MAGIC Now that we're here, would be a good time to start analyzing the data we got. We will do this in the next assignment.
# MAGIC
# MAGIC 7. Save the output to S3 as a parquet file

# COMMAND ----------

