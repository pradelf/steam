# Databricks notebook source
# MAGIC %md
# MAGIC # Songs Analysis

# COMMAND ----------

file_type = 'parquet'

songs = spark.read.parquet("s3://full-stack-bigdata-datasets/Big_Data/YOUTUBE/items_selected.parquet")
songs.printSchema()
songs.count(), len(songs.columns)

# COMMAND ----------

# MAGIC %md
# MAGIC 1. Use `.describe()` on the DataFrame

# COMMAND ----------

songs.describe()

# COMMAND ----------

# MAGIC %md
# MAGIC 2. Count the number of missing values for each column
# MAGIC
# MAGIC *NOTE: Print out the results as a pandas DataFrame*

# COMMAND ----------



# COMMAND ----------

# MAGIC %md
# MAGIC Curiously, we have a few songs with missing `viewCounts`.
# MAGIC
# MAGIC 3. What are the 5 most popular songs? (by view count)

# COMMAND ----------



# COMMAND ----------

# MAGIC %md
# MAGIC 4. Compute:
# MAGIC - total_viewCount: the total viewcount per a channelTitle
# MAGIC - mean_viewCount: the average viewcount per a channel
# MAGIC - max_viewCount: the max view count per a channel
# MAGIC - min_viewCount: the min view count per a channel
# MAGIC - std_viewCount: the standard deviation of view counts per channel
# MAGIC - songsCount: number of songs associated per channel on our list

# COMMAND ----------



# COMMAND ----------

# MAGIC %md
# MAGIC 5. What are the top 5 channels by `mean_viewCount`?

# COMMAND ----------



# COMMAND ----------

# MAGIC %md
# MAGIC 6. What are the top 5 channels by `max_viewCount`?

# COMMAND ----------



# COMMAND ----------

# MAGIC %md
# MAGIC 7. What are the top 5 channels by `total_viewCount`?

# COMMAND ----------



# COMMAND ----------

# MAGIC %md
# MAGIC 8. What are the top 5 channels by number of songs on our service?

# COMMAND ----------



# COMMAND ----------

# MAGIC %md
# MAGIC 9. Scatter plot log of `meanViewCount` vs log of `trackCount`

# COMMAND ----------

