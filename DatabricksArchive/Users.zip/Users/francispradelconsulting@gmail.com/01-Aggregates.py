# Databricks notebook source
# MAGIC %md
# MAGIC # Aggregates ➕➕
# MAGIC
# MAGIC We have used some Spark SQL before, today we will practice with it some more, specifically we will focus on **aggregation operations**.
# MAGIC
# MAGIC ## What will you learn in this course? 🧐🧐
# MAGIC
# MAGIC This course will walk you through the mechanics of aggregation with Spark SQL. Here's the outline:
# MAGIC
# MAGIC * Import functions
# MAGIC * Data
# MAGIC     * Schema
# MAGIC     * Date
# MAGIC * GroupedData
# MAGIC     * `.mean()`
# MAGIC     * `.sum()`
# MAGIC     * `.count()`
# MAGIC     * Other aggregations
# MAGIC     * `.agg(exprs)`
# MAGIC         * exprs as dict
# MAGIC         * exprs as list
# MAGIC         * advanced expressions
# MAGIC
# MAGIC In this notebook we will be using data from the [UCI Machine Learning Repository](https://archive.ics.uci.edu/ml/datasets/Online%20Retail).  
# MAGIC
# MAGIC We'll actually use 👉 [this version](https://www.kaggle.com/carrie1/ecommerce-data) 👈 of the dataset for convenience reasons (csv format).

# COMMAND ----------

filepath = "s3://full-stack-bigdata-datasets/Big_Data/data.csv"

sales = spark.read.format('csv')\
             .option('header', 'true')\
             .option('inferSchema', 'true')\
             .load(filepath)
sales.show(5)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Import functions 🔧🔧
# MAGIC
# MAGIC Before we get started, let's import PySpark's SQL functions. This module contains all the functions you'll need to do everything you could do with regular SQL using PySpark!

# COMMAND ----------

from pyspark.sql import functions as F

# COMMAND ----------

# MAGIC %md
# MAGIC ## Our data 📊📊
# MAGIC Let's take a quick look at the first few rows of our dataset to get a feel of what's in there before we get started.

# COMMAND ----------

sales.show(5)

# COMMAND ----------

# MAGIC %md
# MAGIC We have 8 columns here: 
# MAGIC
# MAGIC * InvoiceNo: the identification number for an order
# MAGIC * StockCode: the identification of the product
# MAGIC * Description: a description of the product
# MAGIC * Quantity: The amount of product purchased
# MAGIC * InvoiceDate: The day and time the order was placed
# MAGIC * UnitPrice: The price for one unit of the product
# MAGIC * CustomerID: The identification number of the customer
# MAGIC * Country: The customer's country of residence
# MAGIC
# MAGIC We're **ready to roll!**

# COMMAND ----------

# MAGIC %md
# MAGIC ### Schema 📋
# MAGIC Let's take a look of the data schema of this DataFrame, make sure everyting is in order.

# COMMAND ----------

sales.printSchema()

# COMMAND ----------

sales.describe().toPandas()

# COMMAND ----------

# MAGIC %md
# MAGIC Looks like some columns have incoherent values, let's clean them up a little before we move on with the analysis:

# COMMAND ----------

sales = sales.filter((F.col("Quantity")>0) & (F.col("UnitPrice")>0)) 
sales.describe().toPandas()
# filter out quantities and unitprices below 0

# COMMAND ----------

# MAGIC %md
# MAGIC Seems like the data Schema did not get any of the types wrong, except for the date, let's convert the date to the proper format before we are ready to move forward.

# COMMAND ----------

# MAGIC %md
# MAGIC ### Date 📆
# MAGIC
# MAGIC Let's work on the date data a little so it's in the proper format.
# MAGIC
# MAGIC Two functions are very useful for handling dates `F.to_timestamp(col, format="")` which converts character strings to [timestamp type](https://spark.apache.org/docs/latest/api/python/reference/api/pyspark.sql.types.TimestampType.html#pyspark.sql.types.TimestampType) and `F.to_date(col,format="")`which converts character strings to [date type](https://spark.apache.org/docs/latest/api/python/reference/api/pyspark.sql.types.DateType.html#pyspark.sql.types.DateType).
# MAGIC
# MAGIC Here are links to the documentation if you want to go further: [to_date](https://spark.apache.org/docs/latest/api/python/reference/api/pyspark.sql.functions.to_date.html), [to_timestamp](https://spark.apache.org/docs/latest/api/python/reference/api/pyspark.sql.functions.to_timestamp.html).

# COMMAND ----------

# MAGIC %md
# MAGIC The function to_timestamp is able to convert the string format date to a timestamp format! All you have to do is write the proper format argument:

# COMMAND ----------

sales = sales.withColumn("InvoiceDateClean", F.to_timestamp(F.col("InvoiceDate"), format="M/d/y H:m"))
sales.show(5)

# COMMAND ----------

# MAGIC %md
# MAGIC Let's drop the previous date column:

# COMMAND ----------

sales = sales.drop(F.col("InvoiceDate"))

# COMMAND ----------

# MAGIC %md
# MAGIC Once the column is in date format, it is possible to extract specific information from the date:

# COMMAND ----------

from pyspark.sql.functions import year, month, dayofmonth, dayofweek, dayofyear, weekofyear

sales.select(year(F.col("InvoiceDateClean"))).show(5)

# COMMAND ----------

# MAGIC %md
# MAGIC ## GroupedData 📊📊
# MAGIC
# MAGIC What's the type of `sales.groupBy('CustomerID')`?

# COMMAND ----------

type(sales.groupBy('CustomerID'))

# COMMAND ----------

# MAGIC %md
# MAGIC A `GroupedData`, here's the link to the [documentation](https://spark.apache.org/docs/2.1.0/api/python/pyspark.sql.html#pyspark.sql.GroupedData).
# MAGIC
# MAGIC We'll go through what we can do with this.

# COMMAND ----------

# MAGIC %md
# MAGIC ### .mean()
# MAGIC
# MAGIC `.mean()` is an alias to `.avg()`

# COMMAND ----------

# MAGIC %md
# MAGIC Compute the average of all numeric columns with `.avg()`

# COMMAND ----------

sales.groupBy('CustomerID').avg().show(5)

# COMMAND ----------

sales.groupBy('CustomerID').mean().show(5)

# COMMAND ----------

# MAGIC %md
# MAGIC ### `.sum()`

# COMMAND ----------

sales.groupBy('customerID').sum().show(5)

# COMMAND ----------

# MAGIC %md
# MAGIC We can select a specific column...

# COMMAND ----------

sales.groupBy('customerID').mean('Quantity').show(5)

# COMMAND ----------

# MAGIC %md
# MAGIC And several columns at once...

# COMMAND ----------

sales.groupBy('customerID').mean('Quantity', 'UnitPrice').show(5)

# COMMAND ----------

# MAGIC %md
# MAGIC This won't work with a list, a tuple or a generator. These need to be **unpacked**:

# COMMAND ----------

# This will fail without unpacking!
col_list = ['Quantity', 'UnitPrice']
sales.groupBy('customerID').mean(*col_list).show(5)

# COMMAND ----------

# MAGIC %md
# MAGIC ### `.count()`
# MAGIC
# MAGIC `count()` is a bit different, it doesn't apply to any column, it count the number of rows in the DataFrame.  
# MAGIC This is different from pandas, where `.count()` count the number of non-null values.

# COMMAND ----------

sales.groupBy('customerID').count().show(5)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Other aggregations 🛠️
# MAGIC
# MAGIC Other aggregation functions include: `.max()`, `.min()` and `.pivot()`.

# COMMAND ----------

sales.groupBy('customerID').pivot('Quantity').count().limit(5).toPandas()
# this creates a pivot table where rows represent cutomer ids, columns
# represent quantities and the values correspond to the result of the aggregation
# function

# COMMAND ----------

# MAGIC %md
# MAGIC ### `.agg(exprs)`
# MAGIC
# MAGIC And a last one: `.agg(exprs)`. This one is a bit meta, it will compute the aggregate of a function given as parameter.  
# MAGIC
# MAGIC From the [Documentation](https://spark.apache.org/docs/2.1.0/api/python/pyspark.sql.html#pyspark.sql.GroupedData.agg):
# MAGIC
# MAGIC > The available aggregate functions are `avg`, `max`, `min`, `sum`, `count`.
# MAGIC
# MAGIC It makes it possible to easily compute more complicated aggregations.

# COMMAND ----------

# MAGIC %md
# MAGIC #### Single dict mapping str to str 
# MAGIC
# MAGIC If `exprs` is a single dict mapping from string to string, then the key is the column to perform aggregation on, and the value is the aggregate function.

# COMMAND ----------

agg_dict = {'Quantity': 'mean', 'UnitPrice': 'sum'}
sales.groupBy('customerId').agg(agg_dict).show(5)

# COMMAND ----------

# MAGIC %md
# MAGIC Can use `'*'` if calling `.count()`. But not with others.

# COMMAND ----------

sales.groupBy('customerId').agg({'*': 'count'}).show(5)

# COMMAND ----------

# MAGIC %md
# MAGIC #### List of aggregate expressions
# MAGIC
# MAGIC Alternatively, `exprs` can also be a "list" of aggregate Column expressions.  
# MAGIC
# MAGIC This requires **unpacking**:

# COMMAND ----------

agg_exprs = (F.mean('Quantity'), F.sum('UnitPrice'))
sales.groupBy('customerId').agg(*agg_exprs).show()
print(type(F.mean('Quantity')))
print(F.mean('Quantity'))

# COMMAND ----------

display(sales.groupBy('customerId').agg(*agg_exprs))

# COMMAND ----------

# MAGIC %md
# MAGIC Now, you can alias, and that's because `.alias()` also returns a _Column Expression_.

# COMMAND ----------

type(F.mean('Quantity').alias('meanQuantity'))

# COMMAND ----------

sales.groupBy('customerId').agg(
    F.mean('Quantity').alias('meanQuantity'),
    F.sum('UnitPrice').alias('totalPrice')
).show(5)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Advanced expressions ⚗️
# MAGIC
# MAGIC It possible to calculate more complicated expressions thanks to `.agg()`:

# COMMAND ----------

sales.groupBy('customerId').agg((F.sum(F.col("UnitPrice"))/F.sum(F.col("Quantity"))).alias("avg_unit_price")).show(5) 