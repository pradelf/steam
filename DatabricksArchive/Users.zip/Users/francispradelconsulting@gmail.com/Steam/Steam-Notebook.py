# Databricks notebook source
# MAGIC %md
# MAGIC # Steam's videogames platform 👾
# MAGIC 960 min
# MAGIC Steam
# MAGIC
# MAGIC ## Company's description 📇
# MAGIC
# MAGIC Steam is a video game digital distribution service and storefront from Valve. It was launched as a software client in September 2003 to provide game updates automatically for Valve's games, and expanded to distributing third-party titles in late 2005. Steam offers various features, like digital rights management (DRM), game server matchmaking with Valve Anti-Cheat measures, social networking, and game streaming services. Steam client's functions include game update automation, cloud storage for game progress, and community features such as direct messaging, in-game overlay functions and a virtual collectable marketplace.
# MAGIC
# MAGIC ## Project 🚧
# MAGIC
# MAGIC You're working for Ubisoft, a French video game publisher. They'd like to release a new revolutionary videogame! They asked you conduct a global analysis of the games available on Steam's marketplace in order to better understand the videogames ecosystem and today's trends.
# MAGIC
# MAGIC ## Goals 🎯
# MAGIC
# MAGIC The ultimate goal of this project is to understand what factors affect the popularity or sales of a video game. But your boss asked you to take advantage of this opportunity to analyze the video game market globally.
# MAGIC
# MAGIC To carry out this project, you will have to adopt different levels of analysis. 
# MAGIC
# MAGIC
# MAGIC
# MAGIC ## Scope of this project 🖼️
# MAGIC
# MAGIC You'll have to use Databricks and PySpark to conduct this EDA. Particularly, you'll have to use Databrick's visualisation tool to create the visualizations.
# MAGIC
# MAGIC The dataset is available in our S3 bucket at the following url: [s3://full-stack-bigdata-datasets/Big_Data/Project_Steam/steam_game_output.json](s3://full-stack-bigdata-datasets/Big_Data/Project_Steam/steam_game_output.json).
# MAGIC
# MAGIC ## Helpers 🦮
# MAGIC
# MAGIC To help you achieve this project, here are a few tips that should help you:
# MAGIC
# MAGIC To adopt different levels of analysis, it might be useful to create different dataframes.
# MAGIC
# MAGIC As the dataset is semi-structured with a nested schema, Pyspark's methods such as getField() and explode() may help you.
# MAGIC
# MAGIC There are some text and date fields in this dataset: Pyspark offers utilitary functions to manipulate these types of data efficiently 💡
# MAGIC
# MAGIC You can use agregate functions and groupBy to conduct segmented analysis.
# MAGIC
# MAGIC ## Deliverable 📬
# MAGIC
# MAGIC To complete this project, you should deliver:
# MAGIC
# MAGIC One or several notebooks including data manipulation with PySpark and data visualization with Databrick's dashboarding tool.
# MAGIC
# MAGIC To make sure the jury can view all the visualizations, please use the "publish" button on Databricks notebooks to create a public url where a copy of your notebook will be available.
# MAGIC
# MAGIC While using the "publish" button, Databricks may tell you that your notebook's size exceeds the maximal size allowed. If this happens, just split your notebook in several notebooks.
# MAGIC
# MAGIC Please copy-paste the link(s) to your published notebooks into your Github repo such that the jury can access it easily. 😌
# MAGIC
# MAGIC

# COMMAND ----------

spark

sc = spark.sparkContext

from pyspark.sql.types import *

from pyspark.sql.types import * # Import types to convert columns using spark sql
from pyspark.sql import functions as F # This will load the class where spark sql functions are contained
from pyspark.sql import Row # this will let us manipulate rows with spark sql

# COMMAND ----------

# Bucket d'input : s3://full-stack-bigdata-datasets/Big_Data/Project_Steam/steam_game_output.json
steam_path = "s3://full-stack-bigdata-datasets/Big_Data/Project_Steam/steam_game_output.json"

df = spark.read.json(steam_path)

df.show(5)
df.select('data.release_date').show(5)

# COMMAND ----------

df.printSchema()

# COMMAND ----------

df.schema.jsonValue()

# COMMAND ----------

from pyspark.sql.types import StructType, StructField
from typing import List, Dict, Generator, Union, Callable

# This is actually written like a scala function, we'll walk you through it
def walkSchema(schema: Union[StructType, StructField]) -> Generator[str, None, None]:
    """Explores a PySpark schema:
    
    schema: StructType | StructField
    
    Yield
    -----
    A generator of strings, the name of each field in the schema
    """
    
    # we define a function _walk that produces a string generator from
    # a dictionnary "schema_dct", and a string "prefix"
    def _walk(schema_dct: Dict['str', Union['str', list, dict]],
              prefix: str = "") -> Generator[str, None, None]:
        assert isinstance(prefix, str), "prefix should be a string" # check if prefix is a string
        
        # this function returns "name" if there's no prefix and "prefix.name" if prefix exists
        fullName: Callable[str, str] = lambda name: ( 
            name if not prefix else f"{prefix}.{name}")
        
        # we get the next name one level lower from the dictionnary
        name = schema_dct.get('name', '')
        
        # if the type is struct then we search for the fields key
        # if fields is there we apply the function again and dig one level deeper in
        # the schema and set a prefix
        if schema_dct['type'] == 'struct':
            assert 'fields' in schema_dct, (
                "It's a StructType, we should have some fields")
            for field in schema_dct['fields']:
                yield from _walk(field, prefix=prefix)
        # if we have a dict type and we can't find fields then we
        # dig one level deeper and apply the _walk function again
        elif isinstance(schema_dct['type'], dict):
            assert 'fields' not in schema_dct, (
                "We're missing some keys here")
            yield from _walk(schema_dct['type'], prefix=fullName(name))
        # If we finally reached the end and found a name we yield the full name
        elif name:
            yield fullName(name)
    
    yield from _walk(schema.jsonValue())

# yield as opposed to return, returns a result but does not stop the function from running, it keeps
# running even after returning one result.

# COMMAND ----------

categorie_nb = df.select(F.explode('data.categories')).count()

# COMMAND ----------

display(categorie_nb)

# COMMAND ----------

categorie_df = df.select(F.explode('data.categories')).distinct().show()

# COMMAND ----------

genre_nb = df.select(F.col('data.genre')).distinct().count()
print(genre_nb)

# COMMAND ----------

genre_df = df.select(F.col('data.genre')).distinct().show(10)

# COMMAND ----------

games_df=df.withColumn('id', F.col('id')) \
          .withColumn('app_id', F.col('data.appid')) \
          .withColumn('name', F.col('data.name')) \
          .withColumn('publisher', F.col('data.publisher')) \
          .withColumn('type', F.col('data.type')) \
          .withColumn('required_age', F.col('data.required_age'))  \
          .withColumn('positive', F.col('data.positive'))  \
          .withColumn('negative', F.col('data.negative'))  \
          .withColumn('languages', F.col('data.languages')) \
          .withColumn('release_date', F.to_timestamp(F.col("data.release_date"), format="y/M/d")) \
          .drop('data')
game_categories_df=df.withColumn('app_id', F.col('data.appid')) \
                     .withColumn('categories', F.explode('data.categories'))
games_df.select('name').orderBy(F.desc("positive")).show(15)
games_platform_df= df.withColumn('id', F.col('id')) \
                     .withColumn('linux', F.col('data.platforms.linux')) \
                     .withColumn('mac', F.col('data.platforms.mac')) \
                     .withColumn('windows', F.col('data.platforms.windows')) 


# COMMAND ----------

games_nb = df.select(F.col('id')).distinct().count()
games_linux_nb=games_platform_df.filter(F.col('linux')== True ).count()
games_mac_nb=games_platform_df.filter(F.col('mac')== True ).count()
games_windows_nb=games_platform_df.filter(F.col('windows')== True ).count()
games_adult_nb =df.filter( \
    (F.col('data.required_age')!='0') \
     & (F.col('data.required_age')!='3') \
     & (F.col('data.required_age')!='5') \
     & (F.col('data.required_age')!='6') \
     & (F.col('data.required_age')!='7+') \
     & (F.col('data.required_age')!='8') \
     & (F.col('data.required_age')!='9') \
     & (F.col('data.required_age')!='10') \
     & (F.col('data.required_age')!='12') \
     & (F.col('data.required_age')!='13') \
     & (F.col('data.required_age')!='14')
     ).count()

categorie_age_nb=df.select('data.required_age').distinct().count()
print("nb de jeu  : ",games_nb)
print("nb jeu windows : ",games_windows_nb,"   mac : ", games_mac_nb, "  linux : ",games_linux_nb)
print("nb de jeu pour adulte  : ",games_adult_nb)
print("nombre de catégorie d'age : ",categorie_age_nb)
df.select('data.required_age').distinct().show()
#truc_df.show(30)

# COMMAND ----------

df.groupBy(F.col('data.required_age')).count().show(20)


# COMMAND ----------

display(categorie_age_nb)

# COMMAND ----------

df.select('data.publisher').distinct().count()

# COMMAND ----------

games_df.groupBy('publisher').count().orderBy(F.desc("count")).show(1000)


# COMMAND ----------

games_df.groupBy('languages').count().orderBy(F.desc("count")).show(50)

# COMMAND ----------

display(games_df.groupBy('release_date').count())

# COMMAND ----------

# MAGIC %md
# MAGIC Your boss gave you a list of examples of questions that would be interesting:
# MAGIC
# MAGIC ### Analysis at the "macro" level
# MAGIC
# MAGIC Q : _Which publisher has released the most games on Steam?_ 
# MAGIC
# MAGIC A : Big Fish Games is the publisher which has released the most games on Steam
# MAGIC
# MAGIC
# MAGIC Q : _What are the best rated games?_
# MAGIC
# MAGIC A: the top rated games on steam platform are :
# MAGIC - Counter-Strike: Global Offensive
# MAGIC - Dota 2
# MAGIC - Grand Theft Auto 
# MAGIC - PUBG: BATTLEGROUNDS
# MAGIC - Terraria
# MAGIC - Tom Clancy's Rain...
# MAGIC - Garry's Mod
# MAGIC - Team Fortress 2
# MAGIC - Rust
# MAGIC - Left 4 Dead 2
# MAGIC - The Witcher 3: Wi..
# MAGIC - Among Us
# MAGIC - Euro Truck Simula...
# MAGIC - Wallpaper Engine
# MAGIC - PAYDAY 2
# MAGIC
# MAGIC
# MAGIC Q : _Are there years with more releases?_ 
# MAGIC
# MAGIC A : 
# MAGIC
# MAGIC
# MAGIC Q: _Were there more or fewer game releases during the Covid, for example?_
# MAGIC
# MAGIC A :
# MAGIC
# MAGIC
# MAGIC Q : _How are the prizes distributed?_ 
# MAGIC
# MAGIC A : 
# MAGIC
# MAGIC
# MAGIC Q : _Are there many games with a discount?_
# MAGIC
# MAGIC A :
# MAGIC
# MAGIC
# MAGIC Q : _What are the most represented languages?_
# MAGIC
# MAGIC A : English
# MAGIC
# MAGIC
# MAGIC Q : _Are there many games prohibited for children under 16/18 ?_
# MAGIC
# MAGIC A : No, only 573 are rated for more than 16 years old people.
# MAGIC

# COMMAND ----------

games_df.select('release_date').show(15)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Genres analysis
# MAGIC
# MAGIC What are the most represented genres?
# MAGIC
# MAGIC Are there any genres that have a better positive/negative review ratio?
# MAGIC
# MAGIC Do some publishers have favorite genres?
# MAGIC
# MAGIC What are the most lucrative genres?
# MAGIC
# MAGIC ### Platform analysis
# MAGIC
# MAGIC Are most games available on Windows/Mac/Linux instead?
# MAGIC
# MAGIC Do certain genres tend to be preferentially available on certain platforms?
# MAGIC
# MAGIC You're free to follow these guidelines, or to choose a different angle of analysis, as long as your analysis reveals relevant and useful information. 🤓

# COMMAND ----------

