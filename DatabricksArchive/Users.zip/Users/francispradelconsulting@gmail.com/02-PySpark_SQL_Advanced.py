# Databricks notebook source
# MAGIC %md
# MAGIC # Advanced Pyspark SQL 🦸✨
# MAGIC
# MAGIC We will explore more advanced functionalities of PySpark SQL.
# MAGIC
# MAGIC ## What will you learn in this course? 🧐🧐
# MAGIC This lecture will cover some more advanced PySpark SQL, here's the outline:
# MAGIC
# MAGIC * Reminder
# MAGIC * Advanced Filters
# MAGIC * Conditionals
# MAGIC     * `.isin()`
# MAGIC     * `.when()`
# MAGIC * Joins
# MAGIC * Array aggregation
# MAGIC     * `F.collect_list()`
# MAGIC     * `F.collect_set()`
# MAGIC     * `F.slice()`
# MAGIC * Window functions
# MAGIC     * `F.rank()`
# MAGIC     * `F.lag()`
# MAGIC     * `F.lead()`
# MAGIC * User defined functions (UDFs)
# MAGIC
# MAGIC ## Setup 💻💻

# COMMAND ----------

songs = spark.read.parquet("s3://full-stack-bigdata-datasets/Big_Data/YOUTUBE/items_selected.parquet")
songs.printSchema()
songs.count(), len(songs.columns)

# COMMAND ----------

from pyspark.sql import functions as F

# COMMAND ----------

# MAGIC %md
# MAGIC ## Reminder 🧠🧠
# MAGIC `isNull()` and `isNotNull()`

# COMMAND ----------

from pyspark.sql import functions as F

# COMMAND ----------

# We transform the column into a boolean indicating True where we find missing values
# and False otherwise, we then convert this boolean to an integer format transforming
# True into 1 and False into 0, then we calculate the sum.
# The result gives us the number of missing values in the id column.
songs.select(F.sum(F.col('id').isNull().cast('int'))).alias('id').show()

# Note that we MUST use a column object to apply our method and cannot simply call
# the column by name

# COMMAND ----------

# MAGIC %md
# MAGIC Let's apply this to all columns

# COMMAND ----------

# We start by defining a function
def count_missing(col_name):
  return F.sum(F.col(col_name).isNull().cast('int')).alias(col_name)
# then we can apply it to all columns using a list comprehension
missing_values = songs.select(*[count_missing(c) for c in songs.columns]).toPandas()
missing_values

# COMMAND ----------

# MAGIC %md
# MAGIC ## Advanced Filters ☕☕
# MAGIC
# MAGIC Filters can be combined to pass multiple conditions using Python's logical operators (`&`, `|`, `~`) with PySpark's `Column` objects of `BooleanType`.  
# MAGIC
# MAGIC ---
# MAGIC - `&`: AND operation `TRUE & FALSE => FALSE`  
# MAGIC - `|`: OR operation `TRUE | FALSE => TRUE`
# MAGIC - `~`: NOT operation `~(TRUE) => FALSE`

# COMMAND ----------

# We'll first create a boolean indicating a single youtube channel
filter_channelId = (F.col('snippet_channelId') == 'UCudKvbd6gvbm5UCYRk5tZKA')
print(type(filter_channelId))
# We'll create a boolean indicating the rows where dislikeCount is missing
filter_null_dislikeCount = (F.col('statistics_dislikeCount').isNull())
print(type(filter_null_dislikeCount))

# COMMAND ----------

# Let's create a multiple filter which will keep only rows that belong to the 
# specific channel and have a missing value in the dislikeCount column
songs.filter(filter_channelId & filter_null_dislikeCount).count()

# COMMAND ----------

# MAGIC %md
# MAGIC We will use Python's unary `~` (invert) operator (see [doc](https://docs.python.org/3/reference/expressions.html#unary-arithmetic-and-bitwise-operations)).

# COMMAND ----------

# Let's check how many rows that are not in that specific channel have missing values 
# for the disike count column
songs.filter(~filter_channelId & ~filter_null_dislikeCount).count()

# COMMAND ----------

# MAGIC %md
# MAGIC Equivalently we could use another way to perform this filter using: `(NOT(A) and NOT(B)) <=> NOT(A or B)`

# COMMAND ----------

songs.filter(~(filter_channelId | filter_null_dislikeCount)).count()

# COMMAND ----------

# MAGIC %md
# MAGIC Warning: do not forget parenthesis.
# MAGIC When using multiple filters make sure you use parenthesis around each condition separated by logical operators

# COMMAND ----------

# This example will fail
# because we did not use parethesis and we did not create objects containing the boolean conditions
# beforehand like we did in the previous example
songs \
  .filter(F.col('snippet_channelID') == 'UCudKvbd6gvbm5UCYRk5tZKA' & F.col('statistics_dislikeCount').isNull()) \
  .count()

# COMMAND ----------

# This will work because the two conditions are made identifiable thanks to the parenthesis
songs \
  .filter((F.col('snippet_channelID') == 'UCudKvbd6gvbm5UCYRk5tZKA') & (F.col('statistics_dislikeCount').isNull())) \
  .count()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Conditionals ✔️❌

# COMMAND ----------

# MAGIC %md
# MAGIC ### `.isin(...)`
# MAGIC
# MAGIC If we wish to filter all elements that belong to a list of values, it is possible to do so using the `.isin` method instead of combining several conditions with the or operator.

# COMMAND ----------

top_channels = songs.groupBy("snippet_channelID").agg(F.sum(F.col("statistics_viewCount")).alias("channel_viewCount"))\
  .orderBy(F.desc(F.col("channel_viewCount"))).limit(5).select("snippet_channelID").toPandas()
top_channels

# COMMAND ----------

songs.filter(F.col('snippet_channelID').isin(top_channels["snippet_channelID"].to_list())).count()

# COMMAND ----------

# MAGIC %md
# MAGIC ### `.when()`
# MAGIC It is possible to create a variable that has different values according to boolean condition!

# COMMAND ----------

songs_filtered = songs \
  .withColumn('ispopularitem', F.when(F.col('snippet_channelID').isin(top_channels["snippet_channelID"].to_list()), True).otherwise(False))\
.orderBy(F.desc("ispopularitem"))
songs_filtered.limit(20).toPandas()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Joins ▶️◀️
# MAGIC Joins let you bring data from several tables into one single table, all you need for this is a common key so that the computer knows which rows may be brought together in the joined table. Let's give an example of this.
# MAGIC
# MAGIC Suppose we wish to add to the song table the information about the total number of songs and the total number of views the various channels cumulate, we could do this with joins.

# COMMAND ----------

# Let's start by creating the aggregated table
aggregates = songs.groupBy("snippet_channelId").agg(F.sum("statistics_viewCount").alias("totalViews"), F.count("*").alias("totalSongs"))
aggregates.limit(5).toPandas()

# COMMAND ----------

# Let's now join this table to the original table to have additional informations about the channels
# the syntax works in the following way:
# left_table.join(right_table, left_table_column == right_table_column)
songs.join(aggregates, songs.snippet_channelId == aggregates.snippet_channelId).limit(5).toPandas()

# COMMAND ----------

# MAGIC %md
# MAGIC We don't have suffixes by default... In particular, if the joining key column will be duplicated, we can deal with this like that:

# COMMAND ----------

# Note that this only works if the joining key column has the same name in both tables
songs.join(aggregates, 'snippet_channelId').limit(5).toPandas()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Array aggregation 📙📘📒📗➡📚
# MAGIC It is possible to aggregate columns to form arrays of values.
# MAGIC ### `F.collect_list()`

# COMMAND ----------

# Here we'll create a column that contains an array listing all the song titles in each channel.
transactions = songs.groupBy('snippet_channelId').agg(F.collect_list('snippet_title').alias('songs_list'))\
  .withColumn("songCount", F.size("songs_list"))\
  .orderBy(F.desc("songCount"))
transactions.limit(5).toPandas()

# COMMAND ----------

# MAGIC %md
# MAGIC ### `F.collect_set()`
# MAGIC Works the same way as collect list, but will result in arrays of distinct elements, as opposed to `.collect_list` which accepts duplicates.

# COMMAND ----------

# Here we'll create a column that contains an array listing all the song titles in each channel.
transactionsSet = songs.groupBy('snippet_channelId').agg(F.collect_set('snippet_title').alias('songs_list'))\
  .withColumn("songCount", F.size("songs_list"))\
  .orderBy(F.desc("songCount"))
transactionsSet.limit(5).toPandas()

# COMMAND ----------

# MAGIC %md
# MAGIC ### `F.slice()`
# MAGIC The `.slice()` method let's you select specific elements from an array

# COMMAND ----------

# here we'll 
transactions \
  .withColumn('items_count', F.size('songs_list')) \
  .withColumn('sliced', F.slice('songs_list', start=1, length=2)) \
  .withColumn('slice_count', F.size('sliced')) \
  .orderBy(F.desc('items_count')) \
  .limit(5).toPandas()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Window functions 🏢🏢
# MAGIC
# MAGIC Window functions make it easy to apply certain functions differently over the data depending on the value of a certain variable. The syntax strongly ressembles that of aggregates.

# COMMAND ----------

from pyspark.sql import Window

# COMMAND ----------

# MAGIC %md
# MAGIC ### `F.rank()`

# COMMAND ----------

# We will create a window function that will sort the data in ascending order
# according to statistics view count for each channel id
w = Window.partitionBy("snippet_channelId").orderBy('statistics_viewCount')
# then we will use this window function to create a rank variable ranking each song in each channel
songs \
  .withColumn('rank', F.rank().over(w)) \
  .orderBy('snippet_channelId','rank') \
  .limit(10).toPandas()

# COMMAND ----------


print(type(w))

# COMMAND ----------

# MAGIC %md
# MAGIC ### `F.lag()` and `F.lead()`
# MAGIC These two methods allow you to create a new column containing the immediately lower or immediatly higher value in a dataframe.

# COMMAND ----------

w = Window.orderBy('statistics_viewCount')

# Here we'll fill the less viewed column witht the view count of the song that's next in descending order
songs \
  .withColumn('less_viewed', F.lag('statistics_viewCount').over(w)) \
  .orderBy(F.desc('statistics_viewCount')) \
  .limit(10).toPandas()

# COMMAND ----------

# MAGIC %md
# MAGIC `.lead()` is the opposite

# COMMAND ----------

# The column more viewed will carry the view count of the song that was more viewed
songs \
  .withColumn('more_viewed', F.lead('statistics_viewCount').over(w)) \
  .orderBy(F.desc('statistics_viewCount')) \
  .limit(10).toPandas()

# COMMAND ----------

# MAGIC %md
# MAGIC ## PySpark's UDF 🧑‍💻
# MAGIC
# MAGIC In Spark SQL we can define our own functions with the UDF function from the `pyspark.sql.functions` module to create our own **U**ser **D**efined **F**unctions (aka UDFs). The default type of the returned variable for UDFs is string. If we would like to return an other type we need to explicitly do so by using the different types from the `pyspark.sql.types` module.
# MAGIC
# MAGIC UDF are useful when you really need to use a python function for which you do not find any equivalent in spark. The UDF let's you use the python function while still benefitting from the spark framework!
# MAGIC
# MAGIC ---
# MAGIC > ⚠️  Using Python User Defined Functions (UDFs) in Apache Spark can have a large negative performance impact.
# MAGIC
# MAGIC ---

# COMMAND ----------

playlog = spark.read.format("csv").option("header", "true").option("inferSchema","true").load("s3://full-stack-bigdata-datasets/Big_Data/youtube_playlog.csv")
playlog.printSchema()

from pyspark.sql.functions import unix_timestamp, from_unixtime
playlog = playlog \
  .withColumn('datetime', from_unixtime('timestamp')) \
  .drop('timestamp') \
  .orderBy('datetime')
import datetime
from pyspark.sql.functions import year, month, dayofmonth, dayofweek, dayofyear, weekofyear
playlog = playlog \
  .withColumn('year', year('datetime')) \
  .withColumn('month', month('datetime')) \
  .withColumn('dayofmonth', dayofmonth('datetime')) \
  .withColumn('dayofyear', dayofyear('datetime')) \
  .withColumn('weekofyear', weekofyear('datetime'))

playlog.printSchema()
playlog.count(), len(playlog.columns)
playlog.limit(5).toPandas()

# COMMAND ----------

# MAGIC %md
# MAGIC First, we need a regular Python function, in our case that's a simple function that takes the first three letters from a character string.

# COMMAND ----------

def three_first_letters(song):
  return song[0:3]

# COMMAND ----------

# MAGIC %md
# MAGIC Seems to work. We will create a UDF and use it.

# COMMAND ----------

from pyspark.sql.types import StringType

three_first_letters_udf = F.udf(
  three_first_letters, StringType())

# COMMAND ----------

test = playlog \
  .withColumn('three_first_letters', three_first_letters_udf('song'))
test.printSchema()
test.show(5)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Ressources 📚📚
# MAGIC
# MAGIC Here are some resources to dig further.
# MAGIC
# MAGIC - [Introducing Window functions in Spark SQL](https://databricks.com/blog/2015/07/15/introducing-window-functions-in-spark-sql.html)
# MAGIC - [Getting started with Spark Part 3: UDFs and Window functions](https://datacenternotes.com/2016/10/03/getting-started-with-spark-part-3-udfs-window-functions/)
# MAGIC - [Using Python aggregate UDFs](https://danvatterott.com/blog/2018/09/06/python-aggregate-udfs-in-pyspark/)
# MAGIC - [Creating a CDF in PySpark](https://danvatterott.com/blog/2019/08/26/creating-a-cdf-in-pyspark/) 
# MAGIC - [PySpark UDFs](https://docs.databricks.com/spark/latest/spark-sql/udf-python.html)