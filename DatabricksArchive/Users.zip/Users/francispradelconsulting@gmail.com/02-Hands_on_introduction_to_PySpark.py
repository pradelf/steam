# Databricks notebook source
# MAGIC %md
# MAGIC # Introduction to PySpark - Part 2 - Dataframes 🗄️🗄️
# MAGIC
# MAGIC ## What will you learn in this course? 🧐🧐
# MAGIC
# MAGIC * DataFrames
# MAGIC     * Differences vs RDDs
# MAGIC         * Pros of DataFrames vs RDDs
# MAGIC     * Creation
# MAGIC         * From a RDD
# MAGIC         * From a pandas DataFrame
# MAGIC * Running SQL queries against DataFrames
# MAGIC     * Select columns in Spark DataFrames
# MAGIC     * Actions
# MAGIC         * `.show()`
# MAGIC         * `.printSchema()`
# MAGIC         * `.take()`
# MAGIC         * `.collect()`
# MAGIC         * `.count()`
# MAGIC         * `.describe()`
# MAGIC         * `display()`
# MAGIC         * `.toPandas()`
# MAGIC         * `..write()`
# MAGIC     * Transformations
# MAGIC         * `.na`
# MAGIC         * `.fill()`
# MAGIC         * `.drop()`
# MAGIC         * `.isNull()`
# MAGIC         * `.replace()`
# MAGIC         * `.sql()`
# MAGIC         * `.select()`
# MAGIC         * `.alias(...)`
# MAGIC         * `.drop(...)`
# MAGIC         * `.limit()`
# MAGIC         * `.filter()`
# MAGIC         * `.selectExpr()`
# MAGIC         * `.dropDuplicates()`
# MAGIC         * `.distinct()`
# MAGIC         * `.orderBy()`
# MAGIC         * `.groupBy()`
# MAGIC         * `.withColumn()`
# MAGIC         * `.withColumnRenamed()`
# MAGIC         * Chaining everything together
# MAGIC         
# MAGIC * Some differences with pandas' DataFrames

# COMMAND ----------

# MAGIC %md
# MAGIC ## DataFrames 🗄️🗄️
# MAGIC
# MAGIC A distributed collection of data grouped into named columns.  
# MAGIC
# MAGIC A DataFrame is equivalent to a relational table in SQL.
# MAGIC
# MAGIC ---
# MAGIC > ⚠️ Although they're called DataFrames, Spark DataFrames are actually closer to SQL tables than pandas'.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ---
# MAGIC > 💡 If you want an API closer to pandas while maintaining fast big data processing capabilities, take a look at [koalas](https://github.com/databricks/koalas) (still in beta).
# MAGIC ---
# MAGIC
# MAGIC Spark DataFrames actually have richer optimizations than both SQL tables and pandas DataFrames (cf. [doc](https://spark.apache.org/docs/2.2.0/sql-programming-guide.html#overview)).

# COMMAND ----------

# MAGIC %md
# MAGIC ### DataFrames vs RDDs 🗄️🆚📃
# MAGIC
# MAGIC Contrary to Spark's RDDs, DataFrames are not schema-less.
# MAGIC
# MAGIC #### Pros of DataFrames vs RDDs ➕➖
# MAGIC
# MAGIC * \- they enforce a schema
# MAGIC * \+ you can run SQL queries against them
# MAGIC * \+ faster than RDDs
# MAGIC * \+ much smaller than RDDs when stored in parquet format

# COMMAND ----------

# MAGIC %md
# MAGIC ### Creation ✨
# MAGIC
# MAGIC There are several ways of creating a Spark DataFrame, one way is to build it from an RDD, or from a pandas DataFrame, another way is to create it directly from a `.csv` or `.parquet` file stored in a distributed file system. (`.parquet` is a compression format for column oriented files, it encodes the values in each column and stores the actual values in correspondance tables, which allows for much smaller storage format).

# COMMAND ----------

# MAGIC %md
# MAGIC #### From a RDD 📃➡🗄️
# MAGIC
# MAGIC Let's see how we can create a Spark DataFrame from and RDD

# COMMAND ----------

sc = spark.sparkContext

# COMMAND ----------

numbers = [i for i in range(10)]
numbers_rdd = sc.parallelize(numbers)

# COMMAND ----------

# This will fail, requires either rdd of tuples or a pandas DataFrame
spark.createDataFrame(numbers_rdd)

# COMMAND ----------

# MAGIC %md
# MAGIC We know how to transform values of a RDD: `.map(...)`. Let's try.

# COMMAND ----------

df = spark.createDataFrame(numbers_rdd.map(lambda k: (k,)))
display(df)

# COMMAND ----------

# MAGIC %md
# MAGIC #### From a pandas DataFrame 🐼➡🗄️

# COMMAND ----------

import pandas as pd
import numpy as np
data_dict = {'a': 1, 'b': 2, 'c': 3, 'd':np.NaN, 'e':3}
pandas_df = pd.DataFrame.from_dict(
    data_dict, orient='index', columns=['position'])
pandas_df

# COMMAND ----------

spark_df = spark.createDataFrame(pandas_df)
spark_df

# COMMAND ----------

display(spark_df)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Running sql queries against DataFrames 🗄️🔢
# MAGIC
# MAGIC Spark let's you run classic SQL queries on your tables, however, using classic SQL in Spark requires you to load the data in memory before running any query. We will use the `.createOrReplaceTempView` Spark DataFrame method in order to load the data in memory under a certain table name, we will then be able to run SQL queries on it.

# COMMAND ----------

spark_df.createOrReplaceTempView('my_table') # Creates a temporary view of the spark dataframe table in memory under the name
# my_table, which we can now query!

# COMMAND ----------

# MAGIC %md
# MAGIC The `.sql` method let's you write queries in SQL while benefiting from the distributed computing advantages of Spark!

# COMMAND ----------

result = spark.sql("SELECT * FROM my_table WHERE position >= 2") # filters elements from my_table where position 
# is greater or equal to 2
display(result)

# COMMAND ----------

# MAGIC %md
# MAGIC This will return a `DataFrame` but **will not compute until an action is called**. Even though the query we wrote is SQL, we use it through the Spark framework which is lazy!

# COMMAND ----------

# MAGIC %md
# MAGIC ### Select columns in Spark DataFrames ⬇️
# MAGIC There are three ways of selecting columns in spark dataframes. Note that columns in dataframes in spark are objects in themselves, and sometimes it is not enough to call them simply by name, we need to refer to the column object directly to prevent ambiguity and bugs.

# COMMAND ----------

# First way: refer to column by indexing
result["position"]

# COMMAND ----------

# Second way: refer to column like an attribute
result.position

# COMMAND ----------

# Third way: use pyspark sql (you'll learn a lot more about this in further lectures)
from pyspark.sql import functions as F
result.select(F.col("position")) # this works only inside pyspark sql commands

# COMMAND ----------

# MAGIC %md
# MAGIC ### Actions 🦸
# MAGIC All actions perform computations, some like `show` or `printSchema` print out results without returning anything, others, like `count` will return a value.

# COMMAND ----------

# MAGIC %md
# MAGIC #### `.show(...)`
# MAGIC Prints out the first 20 values of the DataFrame.

# COMMAND ----------

spark_df.show()

# COMMAND ----------

# MAGIC %md
# MAGIC Default can be changed.

# COMMAND ----------

spark_df.show(2)

# COMMAND ----------

# MAGIC %md
# MAGIC #### `.printSchema()`
# MAGIC Prints out the schema of the DataFrame.

# COMMAND ----------

spark_df.printSchema()

# COMMAND ----------

# MAGIC %md
# MAGIC A schema is a description of the content of structured data. A schema is composed of column names and types. For example, the DataFrame above contains a single column called `position`, which type is `double` meaning a long floating point number. Columns may be of many other types, like `int`, `str`, or even interables like lists or dictionnaries. We will teach you more about schemas when we cover the topics of nested schemas and flat schemas.

# COMMAND ----------

spark_df.columns  # not an `action` (nor a transformation)

# COMMAND ----------

# MAGIC %md
# MAGIC #### `.take(...)`
# MAGIC Compute the first n values of the DataFrame.

# COMMAND ----------

spark_df.take(2)

# COMMAND ----------

# MAGIC %md
# MAGIC As you can see, a PySpark `DataFrame` is a collection of [`Row`](https://spark.apache.org/docs/2.1.0/api/python/pyspark.sql.html#pyspark.sql.Row) objects (cf [doc](https://spark.apache.org/docs/2.1.0/api/python/pyspark.sql.html#pyspark.sql.Row)).

# COMMAND ----------

# MAGIC %md
# MAGIC #### `.collect(...)`
# MAGIC Like `.take(...)` but will take effect on all rows of the DataFrame.

# COMMAND ----------

spark_df.collect()

# COMMAND ----------

# MAGIC %md
# MAGIC ---
# MAGIC ⚠️ `.collect()` will collect all the values, do **NOT** perform this action on a full DataFrame, only on small DataFrames like aggregated results.
# MAGIC
# MAGIC ---

# COMMAND ----------

# MAGIC %md
# MAGIC #### `.count(...)`
# MAGIC Returns the number of `Rows` in the DataFrame

# COMMAND ----------

spark_df.count()

# COMMAND ----------

# MAGIC %md
# MAGIC #### `.describe()`

# COMMAND ----------

spark_df.describe()

# COMMAND ----------

# MAGIC %md
# MAGIC #### Databrick's `display(...)`
# MAGIC For when `.show()` won't cut it...
# MAGIC

# COMMAND ----------

display(spark_df)

# COMMAND ----------

# MAGIC %md
# MAGIC Slow and won't work everywhere... BUT! Let's you access the GraphX interface to do some visualization, all you have to do is click on the barchart button to start visualizing, and use the button plot options that just appeared to refine your viz!

# COMMAND ----------

# MAGIC %md
# MAGIC #### Alternative: converting to pandas with `.toPandas()`
# MAGIC Using `toPandas()`: this is an action, it will compute.  
# MAGIC Hence, do **NOT** forget to `limit` or you'll explode the memory (unless the DataFrame is small, like the result of an aggregate).

# COMMAND ----------

spark_df.limit(5).toPandas() #limit retourne un dataframe.

# COMMAND ----------

spark_df.take(5) #le retour n'est pas un dataframe.

# COMMAND ----------

# MAGIC %md
# MAGIC #### `.write()`
# MAGIC
# MAGIC If you wish to save your files to a location in the S3 it is possible with the `.write()` method.

# COMMAND ----------

spark_df.write("path", mode="overwrite") # mode overwrite will erase any file that 
# already occupies the destination path.

# If you wish to save the file in compressed parquet format it is possible using this option
playlog_processed.write.parquet(output_path, mode='overwrite')

# To load a parquet file as a dataframe use
spark.read.parquet("path")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Transformations 🧙
# MAGIC Let's study some transformations available on spark DataFrames, more exhaustive content may be found in the following link:
# MAGIC - [PySpark Doc](https://spark.apache.org/docs/2.1.0/sql-programming-guide.html)

# COMMAND ----------

# MAGIC %md
# MAGIC #### `.na` for missing values
# MAGIC This is a method associated with spark DataFrame that let's you run jobs on the missing values, like replacig them etc...

# COMMAND ----------

spark_df.na

# COMMAND ----------

# MAGIC %md
# MAGIC #### `.fill(...)`

# COMMAND ----------

spark_df.na.fill(0).show() # this will replace the missing value with 0.0

# COMMAND ----------

# MAGIC %md
# MAGIC #### `.drop()`

# COMMAND ----------

spark_df.na.drop().show() # this will drop the lines containing missing values

# COMMAND ----------

# MAGIC %md
# MAGIC Equivalent to `.dropna()`

# COMMAND ----------

spark_df.dropna(subset=['position']).show() # this will also drop the lines with missing values

# COMMAND ----------

# MAGIC %md
# MAGIC Optional parameter, select a `subset` of columns. This is useful if you only wish to drop lines with missing values on specific columns.

# COMMAND ----------

# MAGIC %md
# MAGIC #### `.isNull()`
# MAGIC Another way to detect missing values in specific columns

# COMMAND ----------

spark_df.select(spark_df["position"].isNull()).show()

# COMMAND ----------

# MAGIC %md
# MAGIC #### `.replace(pattern, value)`
# MAGIC This method will replace every data point equal to `pattern` with `value`.

# COMMAND ----------

spark_df.replace(2, 4).show() 

# COMMAND ----------

# MAGIC %md
# MAGIC Be careful however you may not replace values in the DataFrame that conflict with the schema, for example it is not possible to replace the value 2 in a double type column with a character string.

# COMMAND ----------

spark_df.replace(2, "jedha").show() 

# COMMAND ----------

# MAGIC %md
# MAGIC #### `.sql()` 
# MAGIC We can run SQL queries against a registered view

# COMMAND ----------

spark.sql("SELECT * FROM my_table LIMIT 5").show()

# COMMAND ----------

# MAGIC %md
# MAGIC Multi-line statements need the use of triple quotes `"""`

# COMMAND ----------

spark.sql("""
    SELECT position
    FROM my_table
    LIMIT 5
""").show()

# COMMAND ----------

# MAGIC %md
# MAGIC That's convenient, but we can use PySpark DataFrames API to perform the same operations. The main difference between writing standard SQL and using PysparkSQL is that you will no longer need to load the entire data in memory to start running queries.

# COMMAND ----------

# MAGIC %md
# MAGIC #### `.select()`
# MAGIC The select method works similarly to the select statement in SQL, it let's you access columns of your DataFrame by name.

# COMMAND ----------

spark_df.printSchema()

# COMMAND ----------

spark_df.select('position')

# COMMAND ----------

spark.sql("SELECT position FROM my_table")

# COMMAND ----------

# MAGIC %md
# MAGIC Similar to `spark.sql("SELECT position FROM my_table")`.  
# MAGIC To claim equivalence, we would have to check the execution plan of both (which is beyond the content of this course).

# COMMAND ----------

# MAGIC %md
# MAGIC #### `.alias(...)`

# COMMAND ----------

spark_df.select(spark_df['position'].alias('aliased_column')).show()

# COMMAND ----------

# Won't work on this, it requires a Column selector, this is where the ambiguity of calling colums by name hurts
spark_df.select('position'.alias('aliased_column')).show()

# COMMAND ----------

# MAGIC %md
# MAGIC #### `.drop(...)`
# MAGIC This method let's you remove columns from the DataFrame

# COMMAND ----------

spark_df.drop('position')

# COMMAND ----------

spark_df.drop('position').show()

# COMMAND ----------

# MAGIC %md
# MAGIC #### `.limit(num)`
# MAGIC Like SQL's `LIMIT`.  
# MAGIC Limits the DataFrame to `num` rows.

# COMMAND ----------

spark_df.limit(5).show()

# COMMAND ----------

# MAGIC %md
# MAGIC #### `.filter(...)`
# MAGIC It just works like the WHERE clause in SQL and lets you keep only rows of the DataFrame that verify the condition inside the filter method.

# COMMAND ----------

spark_df.filter((spark_df['position'] < 3) & (spark_df['position'] > 1) )
spark_df.filter((spark_df['position'] < 3) | (spark_df['position'] > 1) )

# COMMAND ----------

spark_df.filter(spark_df.position < 3).show()

# COMMAND ----------

# MAGIC %md
# MAGIC --- 
# MAGIC > 💡 We can even mix both the SQL and SparkSQL APIs
# MAGIC
# MAGIC ---

# COMMAND ----------

# MAGIC %md
# MAGIC #### `.selectExpr`
# MAGIC This method lets you select columns in a DataFrame using SQL statements without having to store a temp view of the table.

# COMMAND ----------

spark_df.limit(5).selectExpr("position * 2", "abs(position)").show()

# COMMAND ----------

# MAGIC %md
# MAGIC #### `.dropDuplicates(...)`
# MAGIC As its name suggests, this method will drop rows that are identical to other rows in the DataFrame, returning a DataFrame where all rows are different.

# COMMAND ----------

spark_df.dropDuplicates().show()

# COMMAND ----------

# MAGIC %md
# MAGIC #### `.distinct()`
# MAGIC This method will return all distinct non missing values in the DataFrame.

# COMMAND ----------

spark_df.distinct().show()

# COMMAND ----------

# MAGIC %md
# MAGIC #### `.orderBy(...)`
# MAGIC Alias to `.sort(...)`
# MAGIC Will sort the DataFrame according to some column.

# COMMAND ----------

spark_df.orderBy('position').show()

# COMMAND ----------

# MAGIC %md
# MAGIC We can call `.desc()` to get a descending order, but that means we need an actual `Column` object to call it on.

# COMMAND ----------

# This will fail
spark_df.orderBy(('position').desc()).show()

# COMMAND ----------

# This won't
spark_df.orderBy(spark_df['position'].desc()).show()

# COMMAND ----------

# MAGIC %md
# MAGIC That's actually one of the key to SparkSQL fluency, but it requires some practice.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ⭐️ No worries, we will review all this later.
# MAGIC
# MAGIC ---

# COMMAND ----------

# MAGIC %md
# MAGIC #### `.groupBy(...)`
# MAGIC
# MAGIC It is possible to group your data according to values in a certain column and then aggregate it, we will learn more on data aggregating in further lecture, this is just a brief introduction.

# COMMAND ----------

spark_df.groupBy('position') 

# COMMAND ----------

# MAGIC %md
# MAGIC Returns a `GroupedData` object. We need to take some action on this.

# COMMAND ----------

# This won't work
spark_df.groupBy('position').show()

# COMMAND ----------

# Another action, this one works
spark_df.groupBy('position').count()

# COMMAND ----------

# MAGIC %md
# MAGIC ⚠️ When applied to a DataFrame, `.count()` is an action. In this case we apply it to an object of type `GroupedData` and it returns a `DataFrame`, e.g. still waiting for an action.

# COMMAND ----------

spark_df.groupBy('position').count().show()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Adding columns ➕
# MAGIC Using pure select is possible, but can feel tedious

# COMMAND ----------

spark_df.select('*', (spark_df.position*2).alias('newColumn')).show()

# COMMAND ----------

# MAGIC %md
# MAGIC #### `.withColumn(...)`
# MAGIC It's usually easier to use `.withColumn` for the same effect.

# COMMAND ----------

spark_df.withColumn('newColumn', 2*spark_df['position']).show()

# COMMAND ----------

# MAGIC %md
# MAGIC #### `withColumnRenamed(...)`
# MAGIC Will change the name of a given column

# COMMAND ----------

spark_df.withColumnRenamed('position', 'newName').show()

# COMMAND ----------

# MAGIC %md
# MAGIC #### Chaining everything together ⛓️

# COMMAND ----------

spark_df \
    .filter(spark_df.position < 2) \
    .groupBy('position') \
    .count() \
    .orderBy('count') \
    .limit(5) \
    .show()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Some differences with pandas' DataFrames 🐼🆚🗄️
# MAGIC
# MAGIC - Accessor: `df.features`, `df['features']` vs `df.select('features')` -> more later
# MAGIC - Also, most (if not all) transformations in PySpark are not `inplace`

# COMMAND ----------

spark_df.position 

# COMMAND ----------

 spark_df['position']

# COMMAND ----------

# MAGIC %md
# MAGIC But in a case like this, just like SQL, the executor can infer the "table" schema, this will work:

# COMMAND ----------

spark_df.select('position')

# COMMAND ----------

# MAGIC %md
# MAGIC It is recommended to always access columns with column objects in select statements and not by name in str directly as it will cause your jobs to fail when running more advanced queries on your DataFrame columns. Using the column object removes any ambiguity.

# COMMAND ----------

spark_df.select('position').show()

# COMMAND ----------

# MAGIC %md
# MAGIC These two statements are returning column objects.
# MAGIC Not very useful by themselves, but can be passed to a `.select(...)`, and then let you run more advanced operations on columns.

# COMMAND ----------

spark_df.select(spark_df.position).show()

# COMMAND ----------

spark_df.select(spark_df['position']).show()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Resources 📚📚
# MAGIC - The part about DataFrames in [Mastering Spark SQL](https://jaceklaskowski.gitbooks.io/mastering-spark-sql/spark-sql-DataFrame.html) (Scala based)
# MAGIC - [Learning Apache Spark with PySpark & Databricks](https://hackersandslackers.com/learning-to-use-apache-spark-pyspark/)