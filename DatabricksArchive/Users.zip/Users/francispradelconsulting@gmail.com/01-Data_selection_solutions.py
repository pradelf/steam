# Databricks notebook source
# MAGIC %md
# MAGIC # Data selection for `songs` analysis
# MAGIC
# MAGIC In this notebook, we will load the data we tidied up and perform columns selection.

# COMMAND ----------

INPUT_FILENAME = 's3://full-stack-bigdata-datasets/Big_Data/YOUTUBE/items_clean.parquet'
songs_raw = spark.read.parquet(INPUT_FILENAME)
df.printSchema()

# COMMAND ----------

len(songs_raw.columns)

# COMMAND ----------

# MAGIC %md
# MAGIC **44 columns, that's quite many columns!** It would take time to explore all of this.  
# MAGIC The goal of this notebook is too quickly scan through the columns and make a selection of some interesting ones that we will explore first.
# MAGIC
# MAGIC We will first get a sense of the different values in each column. Since we will do this for each of the 44 columns, we will write a function that we can then call on all columns.
# MAGIC
# MAGIC Our function will be called `value_counts` and takes 2 parameters:
# MAGIC - `df`: a PySpark DataFrame
# MAGIC - `col_name`: the name of the column for which we want to count the columns
# MAGIC
# MAGIC This function should return the count of each distinct values of the column as a PySpark DataFrame.
# MAGIC
# MAGIC 1. Create the function `value_counts` as per the instructions

# COMMAND ----------

from pyspark.sql import DataFrame
from pyspark.sql import functions as F

def value_counts(df, col_name):
  return df.select(col_name) \
           .groupBy(col_name) \
           .count() \
           .orderBy(F.desc('count'))

# COMMAND ----------

# MAGIC %md
# MAGIC We're now ready to use our function over all columns of `songs_raw`.
# MAGIC
# MAGIC 2. Iterate over each column of `songs_raw` and `.show()` the results of calling `value_counts`

# COMMAND ----------

for col_name in songs_raw.columns:
  value_counts(songs_raw, col_name).show()

# COMMAND ----------

# MAGIC %md
# MAGIC Next part will be done for you, because this is **tedious**, in case you didn't notice, data science is mostly about doing "boring" stuff such as data sourcing and cleaning and _sometimes_ do cool stuff... like machine learning (which we'll study later). 😅
# MAGIC
# MAGIC **Keep in mind that data sourcing and cleaning is CRUCIAL to the success of a data science project, garbage in → garbage out.**
# MAGIC
# MAGIC Today, it's on us, but do not skim on these kind of tasks in your projects.
# MAGIC
# MAGIC We do it for you, but it's nice that you understand. Here is the process 👇.
# MAGIC
# MAGIC First, for convenience, we create an [Enum](https://docs.python.org/3/library/enum.html#module-enum) with 4 attributes:
# MAGIC
# MAGIC - `'not selected'`: this is not our priority, we won't use this column
# MAGIC - `'selected'`: this looks interesting, we will use this column for our next analysis
# MAGIC - `'maybe'`: unsure about this one, maybe for a second pass
# MAGIC - `'later'`: this is interesting, but not prioritary or time-comsuming, we will come back to this later

# COMMAND ----------

from enum import Enum

class Status(Enum):
  NOT_SELECTED = 'not selected'
  SELECTED = 'selected'
  LATER = 'later'
  MAYBE = 'maybe'

# COMMAND ----------

# MAGIC %md
# MAGIC In the following cells, we took a look at the `.show()` statements showing the value counts for each columns.  
# MAGIC As we take notes, we keep track of which selection we make for each column. We told you, **it is tedious work**.

# COMMAND ----------

# MAGIC %md
# MAGIC ### contentDetails
# MAGIC
# MAGIC #### `contentDetails_caption`
# MAGIC Most values are `false` => NOT SELECTED
# MAGIC
# MAGIC #### `contentDetails_contentRating_ytRating`
# MAGIC Apparently, this column seems to indicate if the content is restricted in any way, in particular if it is age restricted.
# MAGIC Most value are not restricted => NOT SELECTED
# MAGIC
# MAGIC #### `contentDetails_definition`
# MAGIC This is the definition of the video, either `sd` (low def) or `hd` (high-def) => MAYBE
# MAGIC
# MAGIC #### `contentDetails_dimension`
# MAGIC Apparently, it is to indicate if the content is using 2Dimension (`2d`) or 3Dimension (`3d`).
# MAGIC Almost all videos are 2-dimensions. => NOT SELECTED
# MAGIC
# MAGIC #### `contentDetails_duration`
# MAGIC ISO8601 encoded duration of the song, obviously many different values, plus that's interesting => SELECTED
# MAGIC
# MAGIC #### `contentDetails_licensedContent`
# MAGIC Boolean: more false than true, not sure it's interesting => MAYBE
# MAGIC
# MAGIC #### `contentDetails_projection`
# MAGIC 2 values, either `rectangular` or `360`, I guess it's either standard video or like Virtual Reality stuff, almost all are `rectangular` => NOT SELECTED

# COMMAND ----------

# MAGIC %md
# MAGIC ### Misc
# MAGIC
# MAGIC #### `etag`
# MAGIC Unique values. I think it's related to Youtube API, plus we got the `id` in another column => NOT SELECTED
# MAGIC
# MAGIC #### `id`
# MAGIC Unique values, unique `id` in Youtube. We'll need this to join with our logs. => SELECTED
# MAGIC
# MAGIC #### `kind`
# MAGIC Only one unique value: `youtube#video`. => NOT SELECTED

# COMMAND ----------

# MAGIC %md
# MAGIC ### Snippet
# MAGIC
# MAGIC #### `snippet_categoryId`
# MAGIC Seems to indicate the category ID (within Youtube), most values are 10 (most likely means 'music').  
# MAGIC Could be interesting. => MAYBE
# MAGIC
# MAGIC #### `snippet_channelId`
# MAGIC The id of the youtube channel the video belongs to, could be interesting to know if some channels are more popular and if users tend to listen to songs from the same channels.  => SELECTED
# MAGIC
# MAGIC #### `snippet_channelTitle`
# MAGIC The title of the channel. Will be useful in combo with `channelId` to perform analysis. => SELECTED
# MAGIC
# MAGIC #### `snippet_defaultAudioLanguage`
# MAGIC The default audio language of the video. Most values are `null`. => LATER
# MAGIC
# MAGIC #### `snippet_defaultLanguage`
# MAGIC The default language of the video. Most values are `null`. => LATER
# MAGIC
# MAGIC #### `snippet_description`
# MAGIC The description of the video as text content. This is text content. => LATER
# MAGIC
# MAGIC #### `snippet_liveBroadcastContent`
# MAGIC Tells if the video was a live broadcast or not. Almost none are. => NOT SELECTED
# MAGIC
# MAGIC #### `snippet_localized_description`
# MAGIC Localized version of the description. Similar to `snippet_description`. => NOT SELECTED
# MAGIC
# MAGIC #### `snippet_localized_title`
# MAGIC The localized title. => MAYBE
# MAGIC
# MAGIC #### `snippet_publishedAt`
# MAGIC Date of publication of the video. That's very interesting. => SELECTED
# MAGIC
# MAGIC #### `snippet_thumbnails_default_height`
# MAGIC Height of the image thumbnails. One unique value. => NOT SELECTED
# MAGIC
# MAGIC #### `snippet_thumbnails_default_url`
# MAGIC URLs of the thumbnails images. Only unique values, although some substring might not be unique, we won't dig into this for the moment. => NOT SELECTED
# MAGIC
# MAGIC #### `snippet_thumbnails_default_width`
# MAGIC Similar to `snippet_thumbnails_default_height`. One unique value. => NOT SELECTED
# MAGIC
# MAGIC #### `snippet_thumbnails_high_height`
# MAGIC Probably similar to `snippet_thumbnails_default_height` and `snippet_thumbnails_high_height`.  
# MAGIC One unique value. => NOT SELECTED
# MAGIC
# MAGIC #### `snippet_thumbnails_high_url`
# MAGIC Similar to `snippet_thumbnails_default_url`. => NOT SELECTED
# MAGIC
# MAGIC #### `snippet_thumbnails_high_width`
# MAGIC Similar to all other dimensions values of the thumbnails image. => NOT SELECTED
# MAGIC
# MAGIC #### `snippet_thumbnails_maxres_height`
# MAGIC Similar to other dimensions values of the thumbnails, this one is a bit different as it has half of missing values.  
# MAGIC Not selecting now but the missing values could capture some time dependant signal (that we might already get from `snippet_publishedAt`). => NOT SELECTED
# MAGIC
# MAGIC #### `snippet_thumbnails_maxres_url`
# MAGIC Same amount of null values as `snippet_thumbnails_maxres_height`, which, kinda makes sense. => NOT SELECTED
# MAGIC
# MAGIC #### `snippet_thumbnails_maxres_width`
# MAGIC Same amount of null values as `snippet_thumbnails_maxres_height` and `snippet_thumbnails_maxres_url`. => NOT SELECTED
# MAGIC
# MAGIC #### `snippet_thumbnails_medium_height`
# MAGIC Same as other thumbnails dimensions. => NOT SELECTED
# MAGIC
# MAGIC #### `snippet_thumbnails_medium_url`
# MAGIC Same as other thumbnails URLs => NOT SELECTED
# MAGIC
# MAGIC #### `snippet_thumbnails_medium_width`
# MAGIC Same as other thumbnails dimensions. => NOT SELECTED
# MAGIC
# MAGIC #### `snippet_thumbnails_standard_height`
# MAGIC Related to thumbnails standard, some missing values. => NOT SELECTED
# MAGIC
# MAGIC #### `snippet_thumbnails_standard_url`
# MAGIC URLs for standard thumbails, shares the same amout of missing values as `snippet_thumbnails_standard_height`. => NOT SELECTED
# MAGIC
# MAGIC #### `snippet_thumbnails_standard_width`
# MAGIC Width for standard thumbails. Missing values amount checks out. => NOT SELECTED
# MAGIC
# MAGIC #### `snippet_title`
# MAGIC Text content, will be useful for analysis. => SELECTED

# COMMAND ----------

# MAGIC %md
# MAGIC ### Statistics
# MAGIC
# MAGIC #### `statistics_commentCount`
# MAGIC Count of comments on the video. => SELECTED
# MAGIC
# MAGIC #### `statistics_dislikeCount`
# MAGIC Count of dislikes on the video => SELECTED
# MAGIC
# MAGIC #### `statistics_favoriteCount`
# MAGIC Count of favorites on the video. That could be of interest, but only one unique value `0`. => NOT SELECTED
# MAGIC
# MAGIC #### `statistics_viewCount`
# MAGIC View counts on the video. => SELECTED

# COMMAND ----------

# MAGIC %md
# MAGIC ### Status
# MAGIC
# MAGIC #### `status_embeddable`
# MAGIC Is it embeddable or not, I'm not really sure what it means, we can dig out later. => LATER
# MAGIC
# MAGIC #### `status_license`
# MAGIC License of the content, either `youtube` or `creativeCommon`. Most are `youtube`. => LATER
# MAGIC
# MAGIC #### `status_privacyStatus`
# MAGIC Wether the video is `public`, public but `unlisted` or probably `private`. We only have values for the first twos. Most are `public`. => LATER
# MAGIC
# MAGIC #### `status_publicStatsViewable`
# MAGIC Are the stats publicly viewable (boolean), most are `true`. => LATER
# MAGIC
# MAGIC #### `status_uploadStatus`
# MAGIC Either `processed` or `uploaded`. Almost all are `processed`. => NOT SELECTED

# COMMAND ----------

# MAGIC %md
# MAGIC Now, we're going to store our results as a pandas DataFrame.  
# MAGIC We create a Python's dictionary which keys are the name of the columns, and values are values of one of the 4 options in our `Enum`.

# COMMAND ----------

selection_dict = {
  'contentDetails_caption': Status.NOT_SELECTED,
  'contentDetails_contentRating_ytRating': Status.NOT_SELECTED,
  'contentDetails_definition': Status.MAYBE,
  'contentDetails_dimension': Status.NOT_SELECTED,
  'contentDetails_duration': Status.SELECTED,
  'contentDetails_licensedContent': Status.MAYBE,
  'contentDetails_projection': Status.NOT_SELECTED,
  'etag': Status.NOT_SELECTED,
  'id': Status.SELECTED,
  'kind': Status.NOT_SELECTED,
  'snippet_categoryId': Status.MAYBE,
  'snippet_channelId': Status.SELECTED,
  'snippet_channelTitle': Status.SELECTED,
  'snippet_defaultAudioLanguage': Status.LATER,
  'snippet_defaultLanguage': Status.LATER,
  'snippet_description': Status.LATER,
  'snippet_liveBroadcastContent': Status.NOT_SELECTED,
  'snippet_localized_description': Status.NOT_SELECTED,
  'snippet_localized_title': Status.LATER,
  'snippet_publishedAt': Status.SELECTED,
  'snippet_thumbnails_default_height': Status.NOT_SELECTED,
  'snippet_thumbnails_default_url': Status.NOT_SELECTED,
  'snippet_thumbnails_default_width': Status.NOT_SELECTED,
  'snippet_thumbnails_high_height': Status.NOT_SELECTED,
  'snippet_thumbnails_high_url': Status.NOT_SELECTED,
  'snippet_thumbnails_high_width': Status.NOT_SELECTED,
  'snippet_thumbnails_maxres_height': Status.NOT_SELECTED,
  'snippet_thumbnails_maxres_url': Status.NOT_SELECTED,
  'snippet_thumbnails_maxres_width': Status.NOT_SELECTED,
  'snippet_thumbnails_medium_height': Status.NOT_SELECTED,
  'snippet_thumbnails_medium_url': Status.NOT_SELECTED,
  'snippet_thumbnails_medium_width': Status.NOT_SELECTED,
  'snippet_thumbnails_standard_height': Status.NOT_SELECTED,
  'snippet_thumbnails_standard_url': Status.NOT_SELECTED,
  'snippet_thumbnails_standard_width': Status.NOT_SELECTED,
  'snippet_title': Status.SELECTED,
  'statistics_commentCount': Status.SELECTED,
  'statistics_dislikeCount': Status.SELECTED,
  'statistics_favoriteCount': Status.NOT_SELECTED,
  'statistics_viewCount': Status.SELECTED,
  'status_embeddable': Status.LATER,
  'status_license': Status.LATER,
  'status_privacyStatus': Status.LATER,
  'status_publicStatsViewable': Status.LATER,
  'status_uploadStatus': Status.NOT_SELECTED
}

import pandas as pd

selection_df = pd.DataFrame.from_dict({k: v.value for k, v in selection_dict.items()},
                                      orient='index', columns=['status'])
selection_df

# COMMAND ----------

# MAGIC %md
# MAGIC We'll check how many of each tag we got.

# COMMAND ----------

selection_df \
  .groupby('status') \
  .agg({'status': 'count'}) \
  .rename(columns={'status': 'count'})

# COMMAND ----------

# MAGIC %md
# MAGIC We only selected 9 columns from the 46 we had at the beginning. This should makes thing easier to analyze.
# MAGIC
# MAGIC 3. Get the selected columns as a list: `selected_columns`

# COMMAND ----------

selected_columns = list(selection_df.loc[selection_df['status'] == "selected"].index)
selected_columns

# COMMAND ----------

# MAGIC %md
# MAGIC 4. Select the `selected_columns` from `songs_raw`: `songs`. Then, print out:
# MAGIC - the schema of the dataframe
# MAGIC - the shape of the DataFrame, e.g. the number of rows and columns

# COMMAND ----------

songs = songs_raw.select(selected_columns)
songs.printSchema()
print("Shape: ", (songs.count(), len(songs.columns)))

# COMMAND ----------

songs.write \
  .parquet("s3://full-stack-bigdata-datasets/Big_Data/YOUTUBE/items_selected.parquet", mode='overwrite')